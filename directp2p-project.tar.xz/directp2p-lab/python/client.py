"""UDP P2P client used by Python desktop & tests. No relay gameplay path."""
import base64
import json
import secrets
import socket
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Callable

from protocol import HELLO, HELLO_ACK, PING, PONG, STATE, KEEPALIVE, STATE_FORMAT, TIMESTAMP_FORMAT, decode, encode


@dataclass
class Stats:
    status: str = "IDLE"
    room: str = ""
    role: str = ""
    peer: str = ""
    rtt_ms: float = -1.0
    rx_states: int = 0
    tx_states: int = 0
    missing_states: int = 0
    state_loss_percent: float = 0.0
    peer_x: float = 0.0
    peer_y: float = 0.0
    peer_angle: float = 0.0


def lan_ip(server_host: str, server_port: int) -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect((server_host, server_port))
            return probe.getsockname()[0]
    except OSError:
        return "127.0.0.1"


class P2PClient:
    def __init__(self, server_host="127.0.0.1", server_port=34781, on_event: Callable | None = None, bind_port=0):
        self.server = (socket.gethostbyname(server_host), int(server_port))
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", bind_port))
        self.sock.settimeout(0.15)
        self.local_port = self.sock.getsockname()[1]
        self.lan = {"ip": lan_ip(server_host, server_port), "port": self.local_port}
        self.client_id = secrets.token_hex(16)
        self.on_event = on_event or (lambda kind, message: None)
        self.stats = Stats()
        self.key: bytes | None = None
        self.candidates: set[tuple[str, int]] = set()
        self.peer_endpoint: tuple[str, int] | None = None
        self.seq = secrets.randbelow(1 << 30)
        self.last_direct = 0.0
        self.first_peer_at = 0.0
        self.pending_pings: dict[int, float] = {}
        self.last_state_seq = None
        self.state_seq = 0
        self.recent_state_seqs = deque(maxlen=2048)
        self._recent_set: set[int] = set()
        self._running = True
        self._want_create = False
        self._want_join = False
        self._last_register = 0.0
        self._last_punch = 0.0
        self._last_ping = 0.0
        self._last_state = 0.0
        self._last_keepalive = 0.0
        self._x = self._y = self._angle = 0.0
        self.send_states = False
        self.thread = threading.Thread(target=self._loop, name="p2p-client", daemon=True)
        self.thread.start()

    def _event(self, kind, message):
        try:
            self.on_event(kind, message)
        except Exception:
            pass

    def host(self):
        self._want_create = True
        self._want_join = False
        self.stats.status = "CREATING"
        self._register("create")

    def join(self, room):
        self.stats.room = room.upper().strip()
        self._want_join = True
        self._want_create = False
        self.stats.status = "JOINING"
        self._register("join")

    def _register(self, typ):
        msg = {"v": 1, "type": typ, "client": self.client_id, "lan": self.lan}
        if self.stats.room and typ != "create":
            msg["room"] = self.stats.room
        try:
            self.sock.sendto(json.dumps(msg, separators=(",", ":")).encode(), self.server)
        except OSError as exc:
            self._event("error", str(exc))
        self._last_register = time.monotonic()

    def move(self, dx=0.0, dy=0.0, da=0.0):
        self._x += dx
        self._y += dy
        self._angle += da
        self.send_state()

    def set_state(self, x, y, angle):
        self._x, self._y, self._angle = float(x), float(y), float(angle)
        self.send_state()

    def _send(self, kind, payload=b"", endpoint=None):
        if self.key is None:
            return
        target = endpoint or self.peer_endpoint
        if target is None:
            return
        self.seq = (self.seq + 1) & 0xffffffff
        packet = encode(self.key, kind, self.seq, int(time.time() * 1000), payload)
        try:
            self.sock.sendto(packet, target)
        except OSError as exc:
            self._event("error", f"sendto: {exc}")
        if kind == STATE:
            self.stats.tx_states += 1

    def send_state(self):
        if self.stats.status == "DIRECT":
            self.state_seq = (self.state_seq + 1) & 0xffffffff
            self._send(STATE, STATE_FORMAT.pack(self.state_seq, self._x, self._y, self._angle))

    def _process_control(self, data, addr):
        # Signaling replies must originate from the configured rendezvous endpoint.
        if addr != self.server:
            return
        try:
            msg = json.loads(data)
        except (ValueError, UnicodeDecodeError):
            return
        if not isinstance(msg, dict) or msg.get("v") != 1:
            return
        typ = msg.get("type")
        if typ == "registered":
            if self.stats.room and self.stats.room != msg.get("room"):
                return
            try:
                key = base64.urlsafe_b64decode(msg["key"] + "=" * (-len(msg["key"]) % 4))
                if len(key) != 32:
                    return
            except (ValueError, KeyError):
                return
            self.key = key
            self.stats.room = msg["room"]
            self.stats.role = msg["role"]
            if self.stats.status in ("CREATING", "JOINING", "IDLE"):
                self.stats.status = "WAITING"
                self._event("registered", f"Комната {self.stats.room} | {self.stats.role}")
            self._want_create = False
            self._want_join = False
        elif typ == "peer":
            if msg.get("room") != self.stats.room:
                return
            for value in (msg.get("peer"), msg.get("lan")):
                if isinstance(value, dict):
                    try:
                        ip = socket.gethostbyname(str(value["ip"]))
                        port = int(value["port"])
                        if 1 <= port <= 65535:
                            self.candidates.add((ip, port))
                    except (OSError, ValueError, KeyError, TypeError):
                        pass
            if self.candidates and self.first_peer_at == 0:
                self.first_peer_at = time.monotonic()
                if self.stats.status != "DIRECT":
                    self.stats.status = "PUNCHING"
                self._event("peer", "Получен peer endpoint, начинаю UDP hole punching")
        elif typ == "error":
            self._event("error", str(msg.get("reason", "server error")))

    def _process_direct(self, data, addr):
        if self.key is None:
            return
        result = decode(self.key, data)
        if result is None:
            return
        # Do not admit unsolicited endpoints before rendezvous provides candidates.
        if not self.candidates and self.peer_endpoint is None:
            return
        kind, seq, timestamp_ms, payload = result
        if addr not in self.candidates and addr != self.peer_endpoint:
            return
        self.last_direct = time.monotonic()
        if self.peer_endpoint is None or self.peer_endpoint != addr:
            self.peer_endpoint = addr
            self.stats.peer = f"{addr[0]}:{addr[1]}"
            self.stats.status = "DIRECT"
            self._event("direct", f"DIRECT UDP {self.stats.peer}")
        elif self.stats.status != "DIRECT":
            self.stats.status = "DIRECT"
            self._event("direct", f"DIRECT UDP восстановлен: {self.stats.peer}")
        if kind == HELLO:
            self._send(HELLO_ACK, endpoint=addr)
        elif kind == PING and len(payload) == 8:
            self._send(PONG, payload, endpoint=addr)
        elif kind == PONG and len(payload) == 8:
            ticket = TIMESTAMP_FORMAT.unpack(payload)[0]
            then = self.pending_pings.pop(ticket, None)
            if then is not None:
                measured = (time.monotonic() - then) * 1000.0
                self.stats.rtt_ms = measured if self.stats.rtt_ms < 0 else self.stats.rtt_ms * 0.7 + measured * 0.3
                self._event("rtt", round(self.stats.rtt_ms, 1))
        elif kind == STATE and len(payload) == STATE_FORMAT.size:
            if seq in self._recent_set:
                return
            if len(self.recent_state_seqs) == self.recent_state_seqs.maxlen:
                self._recent_set.discard(self.recent_state_seqs.popleft())
            self.recent_state_seqs.append(seq)
            self._recent_set.add(seq)
            state_seq = STATE_FORMAT.unpack_from(payload)[0]
            if self.last_state_seq is not None:
                delta = (state_seq - self.last_state_seq) & 0xffffffff
                # Avoid treating reordering and keepalive/ping sequence gaps as state loss.
                # Sequence increments for all packet types, so missing_states is a rough upper bound.
                if 1 < delta < 128:
                    self.stats.missing_states += delta - 1
            if self.last_state_seq is None or 0 < ((state_seq - self.last_state_seq) & 0xffffffff) < 0x80000000:
                self.last_state_seq = state_seq
            self.stats.rx_states += 1
            self.stats.peer_x, self.stats.peer_y, self.stats.peer_angle = STATE_FORMAT.unpack(payload)[1:]
            denominator = self.stats.rx_states + self.stats.missing_states
            self.stats.state_loss_percent = 100 * self.stats.missing_states / max(1, denominator)
            self._event("state", (self.stats.peer_x, self.stats.peer_y, self.stats.peer_angle))

    def _loop(self):
        while self._running:
            try:
                data, addr = self.sock.recvfrom(1500)
                if data.startswith(b"{"):
                    self._process_control(data, addr)
                else:
                    self._process_direct(data, addr)
            except socket.timeout:
                pass
            except OSError:
                if self._running:
                    self._event("error", "UDP socket closed")
                break
            now = time.monotonic()
            if (self._want_create or self._want_join) and now - self._last_register > 2.0:
                self._register("create" if self._want_create else "join")
            if self.stats.room and self.key and now - self._last_register > 3.0:
                self._register("heartbeat")
            if self.candidates and self.stats.status != "DIRECT" and now - self._last_punch > 0.35:
                for address in list(self.candidates):
                    self._send(HELLO, endpoint=address)
                self._last_punch = now
                if self.first_peer_at and now - self.first_peer_at > 15.0:
                    self.stats.status = "NAT_BLOCKED"
            if self.stats.status == "DIRECT":
                if now - self.last_direct > 12.0:
                    self.stats.status = "PUNCHING"
                    self.peer_endpoint = None
                    self._event("disconnected", "Таймаут прямого соединения, переподключение")
                else:
                    if now - self._last_ping > 1.0:
                        ticket = time.monotonic_ns() & 0xffffffffffffffff
                        self.pending_pings[ticket] = now
                        self._send(PING, TIMESTAMP_FORMAT.pack(ticket))
                        self._last_ping = now
                        self.pending_pings = {t: sent for t, sent in self.pending_pings.items() if now - sent < 8}
                    if now - self._last_keepalive > 2.0:
                        self._send(KEEPALIVE)
                        self._last_keepalive = now
                    if self.send_states and now - self._last_state > 0.05:
                        self.send_state()
                        self._last_state = now

    def close(self):
        self._running = False
        self.sock.close()
        self.thread.join(timeout=1.0)
