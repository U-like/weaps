"""Small UDP rendezvous server, NOT a game relay. Python 3.10+ stdlib only."""
import argparse
import base64
import ipaddress
import json
import logging
import secrets
import socket
import time
from collections import defaultdict, deque
from dataclasses import dataclass

TTL = 90.0
MAX_ROOMS = 4000
MAX_DATAGRAM = 1200


@dataclass
class Peer:
    client: str
    endpoint: tuple
    lan: dict | None
    last_seen: float


@dataclass
class Room:
    code: str
    key: str
    host: Peer
    guest: Peer | None = None


class Rendezvous:
    def __init__(self, bind="0.0.0.0", port=34781):
        self.bind, self.port = bind, port
        self.rooms: dict[str, Room] = {}
        self.buckets = defaultdict(deque)
        self.sock = None

    @staticmethod
    def endpoint(peer: Peer):
        return {"ip": peer.endpoint[0], "port": peer.endpoint[1]}

    def send(self, addr, message: dict):
        self.sock.sendto(json.dumps({"v": 1, **message}, separators=(",", ":")).encode(), addr)

    def error(self, addr, reason):
        self.send(addr, {"type": "error", "reason": reason})

    def limited(self, ip: str, now: float):
        q = self.buckets[ip]
        while q and q[0] <= now - 1.0:
            q.popleft()
        if len(q) >= 20:
            return True
        q.append(now)
        return False

    def cleanup(self, now: float):
        for code, room in list(self.rooms.items()):
            if now - room.host.last_seen > TTL:
                del self.rooms[code]
            elif room.guest and now - room.guest.last_seen > TTL:
                room.guest = None
        for ip in list(self.buckets):
            q = self.buckets[ip]
            if not q or q[-1] < now - 3.0:
                del self.buckets[ip]

    @staticmethod
    def validate_lan(value):
        if not isinstance(value, dict):
            return None
        try:
            ip = ipaddress.ip_address(value.get("ip", ""))
            port = int(value.get("port", 0))
            if not (ip.is_private or ip.is_loopback) or not (1 <= port <= 65535):
                return None
            return {"ip": str(ip), "port": port}
        except (ValueError, TypeError):
            return None

    def handle(self, data: bytes, addr):
        now = time.monotonic()
        if len(data) > MAX_DATAGRAM or self.limited(addr[0], now):
            return
        try:
            msg = json.loads(data)
        except (ValueError, UnicodeDecodeError):
            return
        if not isinstance(msg, dict) or msg.get("v") != 1:
            return
        typ = msg.get("type")
        client = msg.get("client")
        if not isinstance(client, str) or len(client) != 32 or any(c not in "0123456789abcdef" for c in client):
            return
        lan = self.validate_lan(msg.get("lan"))
        self.cleanup(now)
        if typ == "create":
            # Idempotence avoids accidentally creating a new room when UDP response gets lost.
            room = next((r for r in self.rooms.values() if r.host.client == client), None)
            if room is None:
                if len(self.rooms) >= MAX_ROOMS:
                    self.error(addr, "server_full")
                    return
                code = "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(10))
                while code in self.rooms:
                    code = "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(10))
                key = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")
                room = Room(code, key, Peer(client, addr, lan, now))
                self.rooms[code] = room
            else:
                room.host.endpoint, room.host.last_seen, room.host.lan = addr, now, lan
            self.registered(addr, room, "host")
            self.announce(room)
        elif typ in ("join", "heartbeat"):
            code = str(msg.get("room", "")).upper().strip()
            room = self.rooms.get(code)
            if room is None:
                self.error(addr, "room_not_found")
                return
            if client == room.host.client:
                role, peer = "host", room.host
            elif room.guest is not None and client == room.guest.client:
                role, peer = "guest", room.guest
            elif typ == "join" and room.guest is None:
                role, peer = "guest", Peer(client, addr, lan, now)
                room.guest = peer
            else:
                self.error(addr, "room_full_or_invalid_client")
                return
            peer.endpoint, peer.lan, peer.last_seen = addr, lan, now
            self.registered(addr, room, role)
            self.announce(room)
        else:
            self.error(addr, "unknown_type")

    def registered(self, addr, room, role):
        self.send(addr, {"type": "registered", "room": room.code, "role": role,
                         "key": room.key, "public": {"ip": addr[0], "port": addr[1]}})

    def announce(self, room):
        if not room.guest:
            return
        for target, other in ((room.host, room.guest), (room.guest, room.host)):
            self.send(target.endpoint, {"type": "peer", "room": room.code,
                                        "peer": self.endpoint(other), "lan": other.lan})

    def serve(self, ready=None, stop=None):
        # This first version supports IPv4; IPv6 is a later connectivity candidate.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.bind((self.bind, self.port))
            sock.settimeout(0.2)
            self.sock = sock
            self.port = sock.getsockname()[1]
            logging.info("Rendezvous listening udp://%s:%d (signaling only)", self.bind, self.port)
            if ready:
                ready.set()
            last_cleanup = time.monotonic()
            while stop is None or not stop.is_set():
                try:
                    data, addr = sock.recvfrom(4096)
                    self.handle(data, addr)
                except socket.timeout:
                    pass
                except OSError:
                    if stop is not None and stop.is_set():
                        break
                    logging.exception("Socket error")
                if time.monotonic() - last_cleanup > 5:
                    self.cleanup(time.monotonic())
                    last_cleanup = time.monotonic()


def main():
    parser = argparse.ArgumentParser(description="DirectP2P signaling server: does NOT relay game packets")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=34781)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    Rendezvous(args.bind, args.port).serve()


if __name__ == "__main__":
    main()
