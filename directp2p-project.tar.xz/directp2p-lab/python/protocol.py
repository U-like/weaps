"""DirectP2P binary datagram v1; interoperable with Android Protocol.kt.

Header: magic(4) kind(1) seq(4, BE) timestamp_ms(8, BE) len(2, BE),
followed by payload and first 16 bytes of HMAC-SHA256(key, header + payload).
No encryption: the HMAC authenticates integrity but not privacy.
"""
import hashlib
import hmac
import struct

MAGIC = b"DPP1"
HEADER = struct.Struct("!4sBIQH")
TAG_LEN = 16
MAX_PAYLOAD = 1000  # MTU-conscious UDP packets
HELLO, HELLO_ACK, PING, PONG, STATE, KEEPALIVE = range(1, 7)
STATE_FORMAT = struct.Struct("!Ifff")
TIMESTAMP_FORMAT = struct.Struct("!Q")


def encode(key: bytes, kind: int, seq: int, timestamp_ms: int, payload: bytes = b"") -> bytes:
    if len(key) < 16:
        raise ValueError("session key too short")
    if not 0 <= kind <= 255 or not 0 <= len(payload) <= MAX_PAYLOAD:
        raise ValueError("invalid datagram")
    data = HEADER.pack(MAGIC, kind, seq & 0xffffffff, timestamp_ms, len(payload)) + payload
    return data + hmac.new(key, data, hashlib.sha256).digest()[:TAG_LEN]


def decode(key: bytes, packet: bytes):
    if len(packet) < HEADER.size + TAG_LEN or len(packet) > HEADER.size + MAX_PAYLOAD + TAG_LEN:
        return None
    magic, kind, seq, timestamp_ms, length = HEADER.unpack_from(packet)
    if magic != MAGIC or length > MAX_PAYLOAD or len(packet) != HEADER.size + length + TAG_LEN:
        return None
    body = packet[:-TAG_LEN]
    if not hmac.compare_digest(hmac.new(key, body, hashlib.sha256).digest()[:TAG_LEN], packet[-TAG_LEN:]):
        return None
    return kind, seq, timestamp_ms, packet[HEADER.size:-TAG_LEN]
