"""Headless desktop tester when Tkinter/display is unavailable."""
import argparse
import time
from client import P2PClient


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--server", default="127.0.0.1")
    p.add_argument("--port", type=int, default=34781)
    cmd = p.add_mutually_exclusive_group(required=True)
    cmd.add_argument("--host", action="store_true")
    cmd.add_argument("--join")
    args = p.parse_args()
    c = P2PClient(args.server, args.port, lambda kind, msg: print(kind, msg, flush=True))
    c.send_states = True
    try:
        c.host() if args.host else c.join(args.join)
        while True:
            time.sleep(1)
            s = c.stats
            print(f"{s.status} room={s.room} peer={s.peer} ping={s.rtt_ms:.1f}ms tx={s.tx_states} rx={s.rx_states} loss~={s.state_loss_percent:.1f}%", flush=True)
    except KeyboardInterrupt:
        pass
    finally:
        c.close()


if __name__ == "__main__":
    main()
