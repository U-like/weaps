"""Run two peers on unrelated networks; exchange DPL2 codes via chat."""
import argparse
import json
import sys
import time
from diagnostic import DiagnosticPeer


def main():
    p = argparse.ArgumentParser(description="DirectP2P manual STUN + UDP diagnostic (no rendezvous/relay)")
    p.add_argument("--role", choices=["host", "join"], required=True)
    p.add_argument("--bind-port", type=int, default=0)
    p.add_argument("--report", default="directp2p-report.json")
    args = p.parse_args()
    peer = DiagnosticPeer(lambda kind, data: print("EVENT", kind, json.dumps(data, ensure_ascii=False), flush=True), bind_port=args.bind_port)
    try:
        print("Waiting 4 seconds for public STUN...", flush=True)
        time.sleep(4)
        if args.role == "host":
            print("OFFER (copy to other peer):\n" + peer.create_offer(), flush=True)
            answer = input("Paste ANSWER from the second peer: ")
            peer.accept_answer(answer)
        else:
            offer = input("Paste OFFER from host: ")
            print("ANSWER (send to host):\n" + peer.accept_offer(offer), flush=True)
        print("Punching... Ctrl+C to save diagnostic report", flush=True)
        while True:
            time.sleep(2)
            s = peer.report()
            print(f"{s['status']} mapped={s['stun_mappings']} selected={s['selected_peer']} "
                  f"punch={s['punch_tx']}/{s['punch_rx']} RTT={s['rtt_ms']}ms", flush=True)
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        peer.save_report(args.report)
        peer.close()
        print("Report saved:", args.report)


if __name__ == "__main__":
    main()
