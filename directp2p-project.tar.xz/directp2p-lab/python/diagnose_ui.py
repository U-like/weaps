"""Desktop UI for serverless UDP NAT diagnostic; exchange DPL2 codes in chat."""
import json
import tkinter as tk
from tkinter import ttk, filedialog
from diagnostic import DiagnosticPeer


class DiagnosticWindow:
    def __init__(self, window):
        self.window = window
        self.peer = None
        window.title('DirectP2P LAB 0.2 — STUN / Hole Punch diagnostic')
        window.geometry('900x725')
        self.frame = ttk.Frame(window, padding=14)
        self.frame.pack(fill='both', expand=True)
        ttk.Label(self.frame, text='Внешний интернет без VPS: STUN → обмен OFFER/ANSWER → direct UDP',
                  font=('TkDefaultFont', 13, 'bold')).pack(anchor='w')
        ttk.Label(self.frame, text='STUN используется только для определения IP:порта. При DIRECT игровые пакеты идут между устройствами.\n'
                              'Передавай коды только тестовому партнёру: OFFER содержит временный секрет.').pack(anchor='w', pady=5)
        line = ttk.Frame(self.frame); line.pack(fill='x', pady=5)
        ttk.Button(line, text='1. Запустить STUN', command=self.start).pack(side='left', padx=4)
        ttk.Button(line, text='2A. HOST: скопировать OFFER', command=self.offer).pack(side='left', padx=4)
        ttk.Button(line, text='2B. JOIN: OFFER → ANSWER', command=self.join).pack(side='left', padx=4)
        ttk.Button(line, text='3. HOST: применить ANSWER', command=self.answer).pack(side='left', padx=4)
        self.state = tk.StringVar(value='Ожидание старта')
        ttk.Label(self.frame, textvariable=self.state, font=('TkDefaultFont', 15, 'bold')).pack(anchor='w', pady=6)
        self.summary = tk.StringVar(value='STUN ещё не запущен')
        ttk.Label(self.frame, textvariable=self.summary, wraplength=850, justify='left').pack(anchor='w')
        ttk.Label(self.frame, text='Вставь OFFER при JOIN или ANSWER при HOST:').pack(anchor='w', pady=(10, 0))
        self.ticket = tk.Text(self.frame, height=5, wrap='char')
        self.ticket.pack(fill='x')
        tools = ttk.Frame(self.frame); tools.pack(fill='x', pady=8)
        ttk.Button(tools, text='Скопировать содержимое поля', command=lambda: self.copy(self.ticket.get('1.0','end-1c'))).pack(side='left', padx=4)
        ttk.Button(tools, text='Сохранить отчёт JSON', command=self.save).pack(side='left', padx=4)
        ttk.Button(tools, text='Скопировать отчёт', command=self.copy_report).pack(side='left', padx=4)
        ttk.Button(tools, text='Стоп', command=self.stop).pack(side='left', padx=4)
        ttk.Label(self.frame, text='Журнал событий (дополнительные детали в JSON):').pack(anchor='w')
        self.log = tk.Text(self.frame, height=14, state='disabled', wrap='word')
        self.log.pack(fill='both', expand=True)
        self.window.protocol('WM_DELETE_WINDOW', self.close)
        self.window.after(300, self.refresh)

    def line(self, message):
        self.log.configure(state='normal'); self.log.insert('end', message + '\n')
        self.log.see('end'); self.log.configure(state='disabled')

    def start(self):
        self.stop()
        try:
            self.peer = DiagnosticPeer(event=lambda typ, val: None)
            self.line(f'STUN launched; same UDP port {self.peer.local_port}. Wait 4–6 seconds for mappings.')
        except Exception as exc:
            self.line(f'ERROR: {exc}')

    def ensure(self):
        if not self.peer:
            raise ValueError('Сначала запусти STUN')
        return self.peer

    def action(self, callback):
        try: callback(self.ensure())
        except Exception as exc: self.line('ERROR: ' + str(exc))

    def copy(self, value):
        self.window.clipboard_clear(); self.window.clipboard_append(value)
        self.window.update()
        self.line('Скопировано в буфер обмена.')

    def offer(self):
        self.action(lambda peer: self.copy(peer.create_offer()))

    def join(self):
        self.action(lambda peer: self.copy(peer.accept_offer(self.ticket.get('1.0', 'end-1c'))))

    def answer(self):
        self.action(lambda peer: peer.accept_answer(self.ticket.get('1.0', 'end-1c')))

    def save(self):
        def do(peer):
            filename = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON', '*.json')], initialfile='directp2p-diagnostic.json')
            if filename:
                peer.save_report(filename)
                self.line(f'Отчёт сохранён: {filename}')
        self.action(do)

    def copy_report(self):
        self.action(lambda peer: self.copy(json.dumps(peer.report(), ensure_ascii=False, indent=2)))

    def refresh(self):
        if self.peer:
            s=self.peer.report()
            self.state.set(f"{s['status']} · {s['role']} · UDP:{s['local_udp_port']} · RTT {s['rtt_ms']} мс")
            self.summary.set('STUN: ' + json.dumps(s['stun_mappings'], ensure_ascii=False) + '\n'
                             + f"Mapping varies: {s['mapping_varies_by_destination']} | Peer: {s['selected_peer']} | "
                             + f"Punch: {s['punch_tx']}/{s['punch_rx']} | Data: {s['game_tx']}/{s['game_rx']}")
            if not hasattr(self, '_event_n'): self._event_n=0
            for event in s['events'][self._event_n:]:
                self.line(f"{event['sec']}s {event['event']}: " + json.dumps({k:v for k,v in event.items() if k not in ('sec','event')},ensure_ascii=False))
            self._event_n=len(s['events'])
        self.window.after(400, self.refresh)

    def stop(self):
        if self.peer: self.peer.close(); self.peer=None
        self._event_n=0

    def close(self):
        self.stop(); self.window.destroy()


def main():
    root=tk.Tk(); DiagnosticWindow(root); root.mainloop()

if __name__=='__main__': main()
