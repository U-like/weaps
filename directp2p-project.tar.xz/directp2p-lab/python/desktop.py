"""Graphical P2P tester, Python stdlib / Tkinter."""
import argparse
import queue
import tkinter as tk
from tkinter import ttk
from client import P2PClient


class Desktop:
    def __init__(self, root, host, port):
        self.root = root
        root.title("DirectP2P — Python ↔ Android")
        root.geometry("760x660")
        self.events = queue.Queue()
        self.client = None
        self.host_var = tk.StringVar(value=host)
        self.port_var = tk.StringVar(value=str(port))
        self.room_var = tk.StringVar()
        self.status_var = tk.StringVar(value="IDLE")
        self.stats_var = tk.StringVar(value="Нет соединения")
        self.position_var = tk.StringVar(value="Локальная позиция: 0, 0")
        self.peer_var = tk.StringVar(value="Позиция партнёра: —")
        self.auto_var = tk.BooleanVar(value=True)
        frame = ttk.Frame(root, padding=16)
        frame.pack(fill="both", expand=True)
        row = ttk.Frame(frame)
        row.pack(fill="x")
        ttk.Label(row, text="Rendezvous IP / DNS:").pack(side="left")
        ttk.Entry(row, textvariable=self.host_var, width=22).pack(side="left", padx=4)
        ttk.Label(row, text="UDP port:").pack(side="left")
        ttk.Entry(row, textvariable=self.port_var, width=7).pack(side="left", padx=4)
        row2 = ttk.Frame(frame)
        row2.pack(fill="x", pady=8)
        ttk.Button(row2, text="Создать комнату (HOST)", command=self.host).pack(side="left", padx=3)
        ttk.Entry(row2, textvariable=self.room_var, width=17).pack(side="left", padx=3)
        ttk.Button(row2, text="Подключиться (JOIN)", command=self.join).pack(side="left", padx=3)
        ttk.Button(row2, text="Стоп", command=self.stop).pack(side="left")
        ttk.Label(frame, textvariable=self.status_var, font=("TkDefaultFont", 16, "bold")).pack(anchor="w", pady=6)
        ttk.Label(frame, textvariable=self.stats_var, wraplength=700).pack(anchor="w")
        ttk.Separator(frame).pack(fill="x", pady=10)
        ttk.Label(frame, text="Игровые данные — позиция игрока (X, Y) и угол", font=("TkDefaultFont", 12, "bold")).pack(anchor="w")
        ttk.Label(frame, text="W/A/S/D или стрелки — двигать персонажа; каждое изменение уходит DIRECT UDP.").pack(anchor="w")
        ttk.Label(frame, textvariable=self.position_var).pack(anchor="w", pady=3)
        ttk.Label(frame, textvariable=self.peer_var).pack(anchor="w", pady=3)
        ttk.Checkbutton(frame, text="Отправлять игровое состояние каждые 50 мс (~20 Гц)", variable=self.auto_var).pack(anchor="w")
        buttons = ttk.Frame(frame)
        buttons.pack(pady=10)
        for label, dx, dy, col, row in (("↑", 0, 1, 1, 0), ("←", -1, 0, 0, 1), ("↓", 0, -1, 1, 1), ("→", 1, 0, 2, 1)):
            ttk.Button(buttons, text=label, command=lambda x=dx, y=dy: self.move(x, y), width=9).grid(column=col, row=row, padx=4, pady=3)
        ttk.Label(frame, text="Лог соединения:").pack(anchor="w")
        self.log_box = tk.Text(frame, height=13, state="disabled", wrap="word")
        self.log_box.pack(fill="both", expand=True)
        root.bind_all("<KeyPress>", self.key_press)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.x = self.y = self.angle = 0.0
        self._tick()

    def _log(self, message):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", str(message) + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _start(self):
        self.stop()
        try:
            self.client = P2PClient(self.host_var.get().strip(), int(self.port_var.get()), lambda kind, msg: self.events.put((kind, msg)))
        except Exception as exc:
            self._log(f"Ошибка: {exc}")
            self.client = None
        return self.client

    def host(self):
        client = self._start()
        if client:
            client.host()
            self._log("Создание комнаты…")

    def join(self):
        room = self.room_var.get().strip()
        if not room:
            self._log("Введите код комнаты")
            return
        client = self._start()
        if client:
            client.join(room)
            self._log(f"Подключение к комнате {room}…")

    def stop(self):
        if self.client:
            self.client.close()
            self.client = None

    def key_press(self, event):
        if isinstance(event.widget, (tk.Entry, tk.Text)):
            return
        mapping = {"w": (0, 1), "a": (-1, 0), "s": (0, -1), "d": (1, 0),
                   "Up": (0, 1), "Left": (-1, 0), "Down": (0, -1), "Right": (1, 0)}
        if event.keysym in mapping:
            self.move(*mapping[event.keysym])

    def move(self, dx, dy):
        self.x += dx
        self.y += dy
        self.position_var.set(f"Локальная позиция: {self.x:.1f}, {self.y:.1f}")
        if self.client:
            self.client.set_state(self.x, self.y, self.angle)

    def _tick(self):
        while not self.events.empty():
            kind, value = self.events.get_nowait()
            if kind == "registered" and self.client:
                self.room_var.set(self.client.stats.room)
            elif kind == "state":
                x, y, angle = value
                self.peer_var.set(f"Позиция партнёра: {x:.1f}, {y:.1f}; угол {angle:.1f}")
            elif kind != "rtt":
                self._log(f"{kind}: {value}")
        if self.client:
            self.client.send_states = self.auto_var.get()
            s = self.client.stats
            self.status_var.set(f"{s.status}    [{s.room}] {s.role}")
            ping = "—" if s.rtt_ms < 0 else f"{s.rtt_ms:.1f} мс"
            self.stats_var.set(f"Peer: {s.peer or '—'} | RTT: {ping} | TX states: {s.tx_states} | RX states: {s.rx_states} | estimated loss: {s.state_loss_percent:.1f}%")
        self.root.after(150, self._tick)

    def on_close(self):
        self.stop()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", default="127.0.0.1")
    parser.add_argument("--port", default=34781, type=int)
    args = parser.parse_args()
    root = tk.Tk()
    Desktop(root, args.server, args.port)
    root.mainloop()


if __name__ == "__main__":
    main()
