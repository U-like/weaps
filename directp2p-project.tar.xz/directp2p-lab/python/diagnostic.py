"""Independent cross-network DPP1 UDP diagnostic (manual signaling, NO relay).

STUN transactions and game packets share exactly one UDP/IPv4 socket.
A private OFFER/ANSWER may be exchanged via an existing chat; no service is
required other than publicly available STUN Binding responders. Public IPv6 is
out of scope in this instrument and must be tested separately in iroh.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import socket
import struct
import threading
import time
from pathlib import Path

from protocol import HELLO, HELLO_ACK, PING, PONG, STATE, STATE_FORMAT, TIMESTAMP_FORMAT, decode, encode

STUN_SERVERS = (("stun.l.google.com", 19302), ("stun.cloudflare.com", 3478))
COOKIE = 0x2112A442
STUN_HEADER = struct.Struct("!HHI12s")
B64 = lambda b: base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def stun_request(txid: bytes) -> bytes:
    if len(txid) != 12:
        raise ValueError("bad txid")
    return STUN_HEADER.pack(0x0001, 0, COOKIE, txid)


def parse_stun_reply(data: bytes, expected_txid: bytes) -> tuple[str, int] | None:
    """Parse validated IPv4 XOR-MAPPED-ADDRESS / MAPPED-ADDRESS (RFC 5389)."""
    if len(data) < 20 or len(expected_txid) != 12:
        return None
    typ, length, cookie, txid = STUN_HEADER.unpack_from(data)
    if typ != 0x0101 or cookie != COOKIE or txid != expected_txid or length % 4 or len(data) < 20 + length:
        return None
    offset, end = 20, 20 + length
    while offset + 4 <= end:
        kind, size = struct.unpack_from("!HH", data, offset)
        start = offset + 4
        if start + size > end:
            return None
        if kind in (0x0020, 0x0001) and size >= 8 and data[start + 1] == 1:
            port = struct.unpack_from("!H", data, start + 2)[0]
            ip = data[start + 4:start + 8]
            if kind == 0x0020:
                port ^= COOKIE >> 16
                ip = bytes(a ^ b for a, b in zip(ip, struct.pack("!I", COOKIE)))
            if 0 < port <= 65535:
                return socket.inet_ntoa(ip), port
        offset = start + ((size + 3) & ~3)
    return None


def encode_ticket(payload: dict) -> str:
    # No whitespace, works through message apps; JSON is uncompressed for portability.
    return "DPL2:" + B64(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())


def decode_ticket(ticket: str) -> dict:
    ticket = "".join(ticket.split())
    if not ticket.startswith("DPL2:") or len(ticket) > 8000:
        raise ValueError("Expected DPL2 ticket (max 8000 characters)")
    raw = base64.urlsafe_b64decode(ticket[5:] + "=" * (-len(ticket[5:]) % 4))
    obj = json.loads(raw)
    if not isinstance(obj, dict) or obj.get("v") != 2 or obj.get("kind") not in ("offer", "answer"):
        raise ValueError("Unknown ticket format")
    if not isinstance(obj.get("sid"), str) or len(obj["sid"]) != 16:
        raise ValueError("Missing session identifier")
    if not isinstance(obj.get("c"), list) or len(obj["c"]) > 24:
        raise ValueError("Invalid candidates")
    for candidate in obj["c"]:
        if not (isinstance(candidate, list) and len(candidate) == 2 and isinstance(candidate[0], str)
                and isinstance(candidate[1], int) and 1 <= candidate[1] <= 65535):
            raise ValueError("Invalid candidate")
        try:
            socket.inet_aton(candidate[0])
        except OSError as exc:
            raise ValueError("Only numeric IPv4 candidates allowed") from exc
    if obj["kind"] == "offer":
        key = base64.urlsafe_b64decode(obj.get("key", "") + "=" * (-len(obj.get("key", "")) % 4))
        if len(key) != 32 or hashlib.sha256(key).hexdigest()[:16] != obj["sid"]:
            raise ValueError("Invalid session key")
    if obj["kind"] == "answer" and "key" in obj:
        raise ValueError("Answer must not expose session key")
    return obj


def get_lan_ipv4() -> str | None:
    for target in ("1.1.1.1", "8.8.8.8"):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((target, 53))  # route lookup; no packet sent
                ip = s.getsockname()[0]
                if not ip.startswith("127."):
                    return ip
        except OSError:
            pass
    return None


class DiagnosticPeer:
    def __init__(self, event=lambda typ, val: None, bind_ip="0.0.0.0", bind_port=0, stun_servers=STUN_SERVERS):
        self.on_event = event
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((bind_ip, bind_port))
        self.sock.settimeout(0.1)
        self.local_port = self.sock.getsockname()[1]
        self.lan = get_lan_ipv4()
        self.key: bytes | None = None
        self.sid: str | None = None
        self.role = "none"
        self.status = "STUN_PROBING"
        self.stun_servers = tuple(stun_servers)
        self.stun_targets: list[tuple[str, int, str]] = []
        self.stun_outstanding: dict[bytes, tuple[str, float, tuple[str, int]]] = {}
        self.stun_mappings: dict[str, tuple[str, int]] = {}
        self.peer_candidates: set[tuple[str, int]] = set()
        self.remote: tuple[str, int] | None = None
        self.rtt_ms = -1.0
        self.tx = 0
        self.rx = 0
        self.punch_tx = 0
        self.punch_rx = 0
        self.states_rx = 0
        self.states_tx = 0
        self.ping_count = 0
        self.pong_count = 0
        self.pending_pings: dict[int, float] = {}
        self.events: list[dict] = []
        self.started = time.monotonic()
        self.peer_started = 0.0
        self.last_packet = 0.0
        self._seq = secrets.randbits(32)
        self._state_seq = 0
        self._last_punch = self._last_stun = self._last_ping = self._last_state = 0.0
        self._run = True
        self._resolve_servers()
        self._thread = threading.Thread(target=self._loop, name="directp2p-diag", daemon=True)
        self._thread.start()

    def _event(self, typ, **fields):
        entry = {"sec": round(time.monotonic() - self.started, 3), "event": typ, **fields}
        self.events.append(entry)
        if len(self.events) > 1500:
            self.events.pop(0)
        self.on_event(typ, fields)

    def _resolve_servers(self):
        for hostname, port in self.stun_servers:
            try:
                for info in socket.getaddrinfo(hostname, port, socket.AF_INET, socket.SOCK_DGRAM):
                    address = info[4][:2]
                    if not any(t[0] == address[0] and t[1] == address[1] for t in self.stun_targets):
                        self.stun_targets.append((address[0], address[1], hostname))
                self._event("dns_ok", name=hostname)
            except OSError as exc:
                self._event("dns_fail", name=hostname, error=str(exc))
        self._event("socket_open", family="IPv4", local_port=self.local_port, lan=self.lan,
                    servers=[t[2] for t in self.stun_targets])

    def create_offer(self) -> str:
        if self.role not in ("none", "host"):
            raise ValueError("This diagnostic was started as joiner")
        if self.key is None:
            self.key = secrets.token_bytes(32)
            self.sid = hashlib.sha256(self.key).hexdigest()[:16]
        self.role = "host"
        return encode_ticket({"v": 2, "kind": "offer", "sid": self.sid, "key": B64(self.key), "c": self._candidates()})

    def accept_offer(self, ticket: str) -> str:
        obj = decode_ticket(ticket)
        if obj["kind"] != "offer":
            raise ValueError("Paste OFFER, not ANSWER")
        if self.role == "host":
            raise ValueError("Host cannot accept offer")
        self.key = base64.urlsafe_b64decode(obj["key"] + "=" * (-len(obj["key"]) % 4))
        self.sid = obj["sid"]
        self.role = "join"
        self.peer_candidates = {tuple(c) for c in obj["c"]}
        self.peer_started = time.monotonic()
        self.status = "PUNCHING"
        self._event("offer_applied", peers=[f"{ip}:{port}" for ip, port in sorted(self.peer_candidates)])
        return encode_ticket({"v": 2, "kind": "answer", "sid": self.sid, "c": self._candidates()})

    def accept_answer(self, ticket: str) -> None:
        obj = decode_ticket(ticket)
        if self.role != "host" or obj["kind"] != "answer" or obj["sid"] != self.sid:
            raise ValueError("Wrong ANSWER or session mismatch")
        self.peer_candidates = {tuple(c) for c in obj["c"]}
        self.peer_started = time.monotonic()
        self.status = "PUNCHING"
        self._event("answer_applied", peers=[f"{ip}:{port}" for ip, port in sorted(self.peer_candidates)])

    def _candidates(self):
        result = set(self.stun_mappings.values())
        if self.lan:
            result.add((self.lan, self.local_port))
        return [[ip, port] for ip, port in sorted(result)][:24]

    def _send_stun(self):
        for ip, port, hostname in self.stun_targets:
            txid = secrets.token_bytes(12)
            address = (ip, port)
            self.stun_outstanding[txid] = (hostname, time.monotonic(), address)
            try:
                self.sock.sendto(stun_request(txid), address)
            except OSError as exc:
                self._event("stun_send_error", server=hostname, error=str(exc))
        self._last_stun = time.monotonic()

    def _send(self, kind: int, data=b"", addr=None):
        if not self.key or not (addr or self.remote):
            return
        self._seq = (self._seq + 1) & 0xffffffff
        try:
            self.sock.sendto(encode(self.key, kind, self._seq, int(time.time() * 1000), data), addr or self.remote)
            self.tx += 1
            if kind == STATE:
                self.states_tx += 1
        except OSError as exc:
            self._event("peer_send_error", error=str(exc))

    def _handle_stun(self, data, addr):
        if len(data) < 20:
            return False
        try:
            _, _, cookie, txid = STUN_HEADER.unpack_from(data)
        except struct.error:
            return False
        if cookie != COOKIE:
            return False
        pending = self.stun_outstanding.pop(txid, None)
        if pending is None:
            return True
        hostname, start, target = pending
        if addr != target:
            self._event("stun_unexpected_origin", server=hostname)
            return True
        result = parse_stun_reply(data, txid)
        if result:
            before = self.stun_mappings.get(hostname)
            self.stun_mappings[hostname] = result
            if before != result:
                self._event("stun_mapped", server=hostname, mapped=f"{result[0]}:{result[1]}",
                            rtt_ms=round((time.monotonic()-start)*1000, 1))
            if self.role == "none":
                self.status = "STUN_OK"
        else:
            self._event("stun_invalid", server=hostname)
        return True

    def _handle_direct(self, data, addr):
        if not self.key or not self.peer_started:
            return
        decoded = decode(self.key, data)
        if decoded is None:
            return
        # Authenticated punch from changed NAT port is permitted after offer/answer.
        # No other sender can pass HMAC without the private session key.
        kind, seq, stamp, payload = decoded
        self.rx += 1
        self.last_packet = time.monotonic()
        if kind in (HELLO, HELLO_ACK):
            self.punch_rx += 1
        if self.remote != addr:
            self.remote = addr
            self.status = "DIRECT"
            self._event("direct_established", peer=f"{addr[0]}:{addr[1]}",
                        candidate_matched=addr in self.peer_candidates,
                        local_behind_nat=self.lan not in {m[0] for m in self.stun_mappings.values()})
        elif self.status != "DIRECT":
            self.status = "DIRECT"
            self._event("direct_restored")
        if kind == HELLO:
            self._send(HELLO_ACK, addr=addr)
        elif kind == PING and len(payload) == 8:
            self._send(PONG, payload, addr)
        elif kind == PONG and len(payload) == 8:
            token = TIMESTAMP_FORMAT.unpack(payload)[0]
            t = self.pending_pings.pop(token, None)
            if t is not None:
                ms = (time.monotonic() - t) * 1000
                self.rtt_ms = ms if self.rtt_ms < 0 else self.rtt_ms * .8 + ms * .2
                self.pong_count += 1
        elif kind == STATE and len(payload) == STATE_FORMAT.size:
            self.states_rx += 1

    def _loop(self):
        while self._run:
            try:
                data, addr = self.sock.recvfrom(1800)
                if not self._handle_stun(data, addr):
                    self._handle_direct(data, addr)
            except socket.timeout:
                pass
            except OSError:
                break
            now = time.monotonic()
            if now-self._last_stun > (3.0 if not self.stun_mappings else 6.0):
                self._send_stun()
            for tid, (host, sent, _) in list(self.stun_outstanding.items()):
                if now-sent > 2.5:
                    self.stun_outstanding.pop(tid, None)
                    if host not in self.stun_mappings:
                        self._event("stun_timeout", server=host)
            if self.peer_candidates and self.key and self.status != "DIRECT" and now-self._last_punch > .35:
                for addr in list(self.peer_candidates):
                    self._send(HELLO, addr=addr)
                    self.punch_tx += 1
                self._last_punch = now
                if now-self.peer_started > 25.0 and self.status != "DIRECT_FAILED":
                    self.status = "DIRECT_FAILED"
                    self._event("direct_timeout", seconds=25, candidates=len(self.peer_candidates))
            if self.status == "DIRECT":
                if now-self.last_packet > 10.0:
                    self.status = "PUNCHING"
                    self.remote = None
                    self._event("direct_lost", idle_seconds=10)
                else:
                    if now-self._last_ping > 1.0:
                        token = secrets.randbits(64)
                        self.pending_pings[token] = now
                        self._send(PING, TIMESTAMP_FORMAT.pack(token))
                        self.ping_count += 1
                        self._last_ping = now
                    if now-self._last_state > .05:
                        self._state_seq += 1
                        self._send(STATE, STATE_FORMAT.pack(self._state_seq, float(self._state_seq%10), 0.0, 0.0))
                        self._last_state = now
            for token, sent in list(self.pending_pings.items()):
                if now-sent > 5.0:
                    self.pending_pings.pop(token, None)
        self._event("socket_closed")

    def report(self) -> dict:
        mappings = {k: f"{v[0]}:{v[1]}" for k, v in self.stun_mappings.items()}
        return {"version": 2, "status": self.status, "role": self.role, "session": self.sid,
                "duration_sec": round(time.monotonic()-self.started, 1), "family": "IPv4",
                "lan": self.lan, "local_udp_port": self.local_port,
                "stun_mappings": mappings, "mapping_varies_by_destination": len(set(mappings.values())) > 1,
                "candidate_count": len(self.peer_candidates), "selected_peer": f"{self.remote[0]}:{self.remote[1]}" if self.remote else None,
                "packets_tx": self.tx, "packets_rx": self.rx, "punch_tx": self.punch_tx, "punch_rx": self.punch_rx,
                "ping_tx": self.ping_count, "ping_rx": self.pong_count, "rtt_ms": round(self.rtt_ms, 1),
                "game_tx": self.states_tx, "game_rx": self.states_rx,
                "inference": self.inference(), "events": list(self.events)}

    def inference(self) -> str:
        if self.remote and self.status == "DIRECT":
            return "DIRECT CONFIRMED by authenticated UDP exchange."
        if not self.stun_mappings:
            return "No STUN Binding responses: UDP, DNS, STUN availability or firewall issue. Inconclusive NAT type."
        if len(set(self.stun_mappings.values())) > 1:
            return "Mapping changed across STUN targets. Endpoint-dependent NAT is possible; STUN candidates may not work."
        if not self.peer_candidates:
            return "STUN works. No peer ticket applied; discovery/signaling not tested."
        return "STUN works but no authenticated peer UDP arrived. Check opposite peer report; filtering/NAT/routing remains unproven."

    def save_report(self, path):
        Path(path).write_text(json.dumps(self.report(), ensure_ascii=False, indent=2), encoding="utf-8")

    def close(self):
        self._run = False
        self.sock.close()
        self._thread.join(timeout=1.0)
