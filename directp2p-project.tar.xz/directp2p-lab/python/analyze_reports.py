"""Side-by-side, evidence-first analysis of two STUN/manual-hole-punch reports."""
import argparse
import json
from pathlib import Path


def classify_pair(a: dict, b: dict) -> dict:
    def has_stun(x): return bool(x.get('stun_mappings'))
    def direct(x): return x.get('status') == 'DIRECT' or any(e.get('event') == 'direct_established' for e in x.get('events', []))
    def candidate_count(x): return x.get('candidate_count', len(x.get('peer_candidates', [])))
    def mapping_varies(x): return bool(x.get('mapping_varies_by_destination'))
    def cnt(x, field): return int(x.get(field) or 0)

    findings = []
    if direct(a) and direct(b):
        code = 'DIRECT_CONFIRMED'
        findings.append('Обе стороны получили аутентифицированные игровые UDP-пакеты напрямую, без relay.')
        findings.append('Если при такой же сети iroh показывает RELAY, сравните адресные кандидаты, IPv6, сетевые настройки, жизненный цикл и маршруты iroh.')
    elif direct(a) or direct(b):
        code = 'ONE_SIDED_DIRECT'
        findings.append('Только одна сторона сообщила о DIRECT. Проверьте финальные времена снимков и счётчики пакетов на обеих сторонах.')
        findings.append('Возможен разрыв/смена NAT mapping или потерянный пакет ответа. Это не подтверждённая стабильная двусторонняя связь.')
    elif not has_stun(a) or not has_stun(b):
        code = 'STUN_FAILURE'
        sides = ', '.join(name for name, x in [('A',a),('B',b)] if not has_stun(x))
        findings.append(f'Нет ответа STUN на стороне {sides}. До диагностики hole punching надо проверить DNS/UDP доступность этой стороны.')
    elif not candidate_count(a) or not candidate_count(b):
        code = 'SIGNALING_INCOMPLETE'
        findings.append('Не применён OFFER/ANSWER либо в билете нет сетевых адресов. Проверьте, что оба устройства получили ответ STUN ДО обмена кодами.')
    elif cnt(a,'punch_tx') == 0 or cnt(b,'punch_tx') == 0:
        code = 'NO_PUNCH_SENT'
        findings.append('Одна из сторон не отправляла проверочные UDP-пакеты. Проверьте, что host применил ANSWER, обе стороны не уснули и код относится к одной сессии.')
    else:
        code = 'PUNCH_FAILED'
        findings.append('Обе стороны отправляли UDP-пробы и получили адреса STUN, но аутентифицированный обмен между ними не подтверждён.')
        findings.append('Возможные причины: endpoint-dependent NAT mapping/filtering, CGNAT, firewall, неверная/устаревшая mapping или приложение в фоне.')
        findings.append('Это не доказывает, что NAT симметричный или что direct невозможен при IPv6/другом протоколе.')
    if mapping_varies(a) or mapping_varies(b):
        findings.append('Внешние STUN mapping отличаются в зависимости от сервера. Endpoint-dependent mapping вероятен; это наблюдение, не полная классификация NAT.')
    if not mapping_varies(a) and not mapping_varies(b) and has_stun(a) and has_stun(b):
        findings.append('Mapping между двумя проверенными STUN-серверами совпадает, но NAT-фильтрация остаётся неизвестной.')
    return {
        'result': code,
        'A': {k: a.get(k) for k in ('status', 'family', 'stun_mappings', 'mapping_varies_by_destination',
                                  'punch_tx', 'punch_rx', 'rtt_ms', 'selected_peer')},
        'B': {k: b.get(k) for k in ('status', 'family', 'stun_mappings', 'mapping_varies_by_destination',
                                  'punch_tx', 'punch_rx', 'rtt_ms', 'selected_peer')},
        'findings': findings,
        'limitation': 'Only IPv4 raw UDP evaluated. DirectP2P and iroh use different local ports/transport. Tests do not classify all NAT behaviors or IPv6.'
    }


def main():
    parser = argparse.ArgumentParser(description='Compare both peers diagnostic JSON reports')
    parser.add_argument('A'); parser.add_argument('B')
    args = parser.parse_args()
    report = classify_pair(json.loads(Path(args.A).read_text(encoding='utf-8')),
                           json.loads(Path(args.B).read_text(encoding='utf-8')))
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
