# DirectP2P LAB 0.2 — NAT diagnostic pipeline

This lab is **not iroh**. It isolates raw UDP/IPv4 path viability from the
existing iroh / QUIC / Godot implementation. STUN servers are public, but **no
service relays game packets**. OFFER/ANSWER are transmitted via a pre-existing
messenger (e.g., P2P Chat / Cloudflare), not through STUN. No user account or
VPS is required to perform this *manual* test.

## The measurement chain

1. **Socket:** bind one UDP/IPv4 socket with a stable local port. Keep the app
   open during the entire test. Record local interface IP and UDP port.
2. **DNS:** resolve Google `stun.l.google.com:19302` and Cloudflare
   `stun.cloudflare.com:3478` (two different providers).
3. **STUN:** issue RFC 5389 Binding Requests from the **same socket**. Validate
   returned transaction IDs and XOR-MAPPED-ADDRESS. Record public IP:port
   mappings, per-server RTT and timeouts. Re-probe every ~6 seconds to keep
   translations warm. STUN isn't a matchmaking service.
4. **Manual signaling:** Host creates `DPL2:...` OFFER with secret and its
   current candidates; guest pastes it and generates ANSWER; host pastes
   ANSWER. Share these codes privately via any working messenger. The codes
   include a secret that authorizes access to this test session.
5. **Hole punching:** after both codes applied, both peers send HMAC-protected
   HELLO to every candidate ~3 times/s for 25s, then keep retrying. A packet
   with a valid session MAC is accepted from a *different* source port too,
   because endpoint-dependent NAT can rebind addresses.
6. **Verify DIRECT:** require an actual authenticated UDP packet. Once linked,
   send direct PING/PONG (RTT) and 20 Hz game-state packets. No fallback to
   relay. Only 'DIRECT' means this test has confirmed a two-way UDP path.
7. **Collect** one JSON report from **each** peer; inspect mapping differences,
   matching session IDs, candidate counts, tx/rx counts, RTT and event logs.
8. **Classify:** use `python/analyze_reports.py a.json b.json` for a
   conservative, non-definitive diagnosis.

## First live test (desktop ↔ Android, different networks)

1. Keep PC on its home broadband connection, Android on **mobile data**;
   Wi-Fi and VPN **off** on Android. If the PC has VPN, turn it off as well.
2. Desktop: `python python/diagnose_ui.py`, click **Запустить STUN**. Wait
   4–6 seconds until `stun_mapped` for at least one server (preferably two).
3. Android: install version `0.2.0-diag`, open the section at the top titled
   **ДИАГНОСТИКА ИНТЕРНЕТ-P2P**, click **Запустить STUN**, wait until mappings
   appear. Do **not** use the old rendezvous/room buttons for this test.
4. Desktop HOST: click **HOST: скопировать OFFER**, send it privately to
   Android with an existing messenger. Android JOIN: paste into OFFER/ANSWER
   input and click **JOIN: применить OFFER и скопировать ANSWER**.
5. Send ANSWER from Android to PC. Desktop HOST: paste ANSWER in its field,
   click **HOST: применить ANSWER**.
6. Leave both instances open/foreground (Android split-screen if switching to
   P2P Chat). Wait 25–40 seconds. Take screenshots of STUN map, selected
   route, send/receive counts, direct status, RTT.
7. Android: **Скопировать диагностический отчёт (JSON)**; paste into a private
   note and save it as `android.json` on PC. Desktop: **Сохранить отчёт JSON**
   as `desktop.json`. Analyze:

   ```bash
   python python/analyze_reports.py desktop.json android.json
   ```

8. Repeat with Android **HOST** and desktop **JOIN**, and separately with
   another carrier if possible. Exchange **fresh** OFFER/ANSWER after each
   network change. Always start new diagnosis so old NAT mappings aren't
   reused.

### Minimal headless desktop variant

```bash
python python/diagnose_cli.py --role host --report desktop.json
# second instance (another PC, or alongside Android):
python python/diagnose_cli.py --role join --report guest.json
```

## What the evidence means

| Observation | Implication | Not proof of |
| --- | --- | --- |
| No STUN mapping | DNS/UDP STUN failure or timeout | Symmetric NAT |
| Two STUN mappings differ | Possible endpoint-dependent mapping / load balancer | Exact NAT type |
| STUN works, no peer candidates | Ticket/signaling/start timing problem | Carrier block |
| Both sides send probes, neither gets authentic reply | Filtering, endpoint-dependent NAT, routing, stale mapping, background suspension, or other issue | That *all* direct connectivity is impossible |
| DIRECT + two-sided game/RTT | Authenticated UDP direct path exists for this socket pair | That the iroh socket automatically has the same path |
| Independent UDP succeeds but iroh stays RELAY | Investigate iroh candidate gathering, path selection, socket lifecycle and IPv6 | A specific iroh bug without further logs |

**Important limitations:** Tests are IPv4 only. Mobile IPv6 can work when
IPv4 CGNAT cannot. STUN Binding from two servers does not fully characterize
NAT filtering or predict success to a third destination. Manual candidate
exchange takes time; NAT mappings may change. Unsuccessful UDP probing doesn't
prove every protocol will fail, and a successful direct test doesn't prove
iroh will choose the same route. Keep both apps foreground; some phone OSes
suspend background sockets. Sensitive endpoint IPs appear in reports, so
redact them when posting publicly. OFFER includes the shared session secret;
reports **do not** include that key. The test uses integrity-only HMAC, not
encryption; don't send real user or private gameplay data.

## Iroh comparison without changing messenger

For the same mobile data ↔ PC network pair, record **iroh selected path**,
RTT, whether a VPN is running, and whether the peer is using a full ticket or
only EndpointID. Compare with independent DPL2 outcomes. The following are
specific areas of the existing `U-like/p2p_messenger` source:

- `app/src/main/java/org/p2pchat/app/ChatPeer.kt`: `presetN0`, optional
  `presetMinimal` with custom relay; endpoint restart when Android changes
  network, `conn.paths()` selected relay/IP observation.
- `app/src/main/java/org/p2pchat/app/GameSessions.kt`: separate game ALPN,
  datagram sending/reading, game path, RTT and p95.
- `infra/iroh-relay/`: separate optional custom-relay RTT experiment; it
  cannot make a carrier's UDP mapping restrictions disappear.

**Do not** infer from one-router Ethernet↔Wi-Fi DIRECT that WAN hole punching
has ever worked: that scenario can use private LAN IPs and no NAT traversal.
