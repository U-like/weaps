# DirectP2P LAB 0.2 — Android ↔ Python direct UDP and NAT diagnostics

**NEW in 0.2 — serverless diagnostic mode:** Public Google/Cloudflare STUN
probes, manual `DPL2` OFFER/ANSWER exchange via existing chat, authenticated
UDP hole punching, route counters, RTT, JSON export and conservative offline
analysis. **No rental, registration or custom rendezvous is required for this
manual test.** See [DIAGNOSTICS.md](DIAGNOSTICS.md) for the exact mobile↔PC
procedure. The existing room/rendezvous game mode remains available below the
diagnostic section of the Android UI.

A real, minimal cross-platform testbench for **host-anywhere direct UDP P2P**. The host can be a mobile phone without a public IPv4 address, provided the participants' NATs allow UDP hole punching. The original automatic-room test uses a small signaling (rendezvous) server for discovery but **never relays gameplay packets**.

## Components

| Directory | Role |
|---|---|
| `python/rendezvous.py` | Stateless *gameplay*, stateful room signaling: room IDs, external UDP endpoints and shared session keys. Python stdlib only. |
| `python/desktop.py` | Tkinter desktop UI: create/join room, direct status, ping, estimated state-packet loss, 20 Hz player coordinates. |
| `python/client_cli.py` | Headless game client for terminals/servers. |
| `python/client.py` | Python P2P connection manager and typed binary game packets. |
| `python/diagnostic.py` | Independent IPv4 STUN / manual-ticket / direct-UDP instrument. |
| `python/diagnose_ui.py` | Standalone GUI for serverless diagnostic (also linked from desktop). |
| `python/diagnose_cli.py` | Headless serverless test (host or join). |
| `python/analyze_reports.py` | Compare two JSON reports and suggest next checks. |
| `DIAGNOSTICS.md` | Reproducible A/B matrix, step-by-step mobile test, interpretation. |
| `python/protocol.py` | DPP1 binary wire format, HMAC authentication, state serialization. |
| `android/` | Native Android Kotlin client, same DPP1 protocol, independent STUN/manual diagnostics and 20 Hz state sync; no third-party Android libraries. |
| `tests/` | In-process LAN/loopback integration tests and Python ↔ Kotlin HMAC test vector. |

### Local test on one PC, no public IP, no DNS needed

Requires Python 3.10+.

Terminal 1:
```bash
python python/rendezvous.py --bind 127.0.0.1 --port 34781
```
Terminal 2:
```bash
python python/desktop.py --server 127.0.0.1 --port 34781
```
Terminal 3:
```bash
python python/desktop.py --server 127.0.0.1 --port 34781
```
Create a room on A, copy the room code into B and Join. Both UIs should show `DIRECT`; move with arrows to send gameplay state.

On a Linux host without a graphical display:
```bash
python python/client_cli.py --server 127.0.0.1 --host
# then, in another terminal, use printed room code:
python python/client_cli.py --server 127.0.0.1 --join ROOMCODE
```

### Android ↔ PC on same Wi-Fi

1. On PC start `python python/rendezvous.py --bind 0.0.0.0 --port 34781`.
2. Allow **incoming UDP 34781** in the PC firewall and find the PC's Wi-Fi LAN IPv4 (for example `192.168.1.50`).
3. On Android, set Rendezvous to this **PC LAN IPv4**, port `34781` (not `127.0.0.1`, which means the phone itself).
4. In the desktop Python UI, set Rendezvous to `127.0.0.1:34781`. Create a room, then join it from Android using the code; or let Android host and Python join.
5. Confirm **DIRECT** on both. Controls continuously exchange `(X,Y,angle)` at 20 Hz. RTT is measured *directly* between peers.
6. An Android emulator can use `10.0.2.2` to reach the host PC's localhost on standard Android Emulator setups.

### Cross-network test: mobile data ↔ desktop

For discovery across unrelated private networks, the rendezvous process **must** be UDP-reachable on a publicly routable address. This may be a small free-capacity VM with a public IPv4 and inbound UDP port 34781, a university/office machine with forwarded UDP, or another accessible host. You do **not** need a public IP for either **game player**, including the player who presses HOST.

On the reachable server:
```bash
python3 python/rendezvous.py --bind 0.0.0.0 --port 34781
```
Open UDP 34781 on OS/provider firewalls, then set that reachable IP/domain on each client. Do not set the other player's private IP as rendezvous address. A public STUN server alone does **not** provide room discovery or coordinated NAT traversal.

When direct UDP works, all game packets go from `A_IP:A_PORT` to `B_IP:B_PORT`; rendezvous only receives small JSON registration/heartbeat messages. For endpoint-dependent/symmetric NAT, some CGNATs, strict carrier firewalls, or blocked UDP, direct may be **impossible**. This lab intentionally does not silently fallback to relay. After ~15 seconds of repeated probes the status becomes `NAT_BLOCKED` while retries continue. Geographical closeness helps only once a viable route exists and the ISP actually routes traffic locally.

### Security / correctness / limits

- Short-lived random, unguessable 10-character room code and random 256-bit session key. Direct datagrams use a 16-byte HMAC-SHA256 tag for integrity. The server sends that secret over **unencrypted UDP**; an attacker on path or the server operator can read it. **Do not send real user credentials, private information, or production gameplay** on this prototype. Production requires authenticated encryption (e.g. DTLS/Noise) and authenticated rendezvous.
- One host + one guest per room in this MVP. Add a per-peer candidate graph and host ↔ N connections for a multiplayer game.
- Game state packets are **unreliable, unordered** and 20 Hz; the receiver displays the most recently accepted sequence. Reliable messages, channels, interpolation, prediction, delta compression, security, relay fallback and host migration are future modules.
- Direct packet loss is an estimate over 20 Hz STATE sequence numbers, not the entire network; startup losses before first received state are invisible. RTT uses direct PING/PONG, not server RTT.
- Uses one UDP socket for rendezvous + peer; this is vital because NAT mappings are associated with socket ports.
- **IPv4-only prototype.** The 0.2 diagnostic compares mapped IPv4 endpoints across two STUN services; this is a hint, not a full RFC 5780 NAT classification. IPv6, true ICE candidate priority, and more sophisticated traversal remain future additions.
- Android socket lives while Activity is open. No background service or wake lock; mobile OS may suspend it when app is backgrounded.
- Android and Python implement the same native wire protocol **without embedding C# LiteNetLib or FishNet**. For Unity/FishNet later, implement a C# DPP1 adapter or replace the transport with LiteNetLib's `NetManager` after successful rendezvous/hole punching. FishNet alone is not a NAT traversal service.

### Protocol DPP1

All direct datagrams:

```
magic         4 bytes  "DPP1"
kind          1 byte   HELLO=1, HELLO_ACK=2, PING=3, PONG=4, STATE=5, KEEPALIVE=6
sequence      4 bytes  uint32, big-endian
wall clock    8 bytes  uint64 ms, big-endian (diagnostic only)
payload_size  2 bytes  uint16, big-endian
payload       0-1000 bytes
HMAC          16 bytes first 16 bytes of HMAC-SHA256(session_key, all above)
```

`STATE` payload: `state_sequence uint32, x float32, y float32, angle float32`, all big-endian. No application relay packets are accepted or forwarded by `rendezvous.py`.

### Tests

```bash
python -m unittest discover -s tests -v
# Kotlin/JVM protocol compatibility test:
kotlinc android/app/src/main/java/dev/directp2p/lab/Protocol.kt -d /tmp/p2p.jar
# Protocol.selfTest() compares bytes to the test vector printed by Python.
```

### Build Android APK

Android Studio: open `android/` → **Build APK(s)**.

CI on Linux with Android SDK & JDK 17+:
```bash
cd android
bash scripts/ensure_gradle_wrapper.sh
bash gradlew :app:assembleDebug
# Android APK: app/build/outputs/apk/debug/app-debug.apk
```

The Gradle wrapper and AGP versions are pinned; the `.github/workflows/directp2p-android.yml` GitHub Actions job sets up the SDK and uploads an installable APK.

## Roadmap

1. Verify Android ↔ Python on Wi-Fi and across two real mobile carriers; record direct success rate, NAT and RTT.
2. Add IPv6 + STUN candidates, symmetric-NAT diagnosis, ICE-style connectivity checks and robust reconnect on Wi-Fi → mobile data changes.
3. Add N-peer room and host selection, game tick channels, ACK/reliable-ordered messages, interpolation and delta compression.
4. Add authenticated encryption and anti-abuse server controls; design a FishNet/LiteNetLib Unity transport adapter.
