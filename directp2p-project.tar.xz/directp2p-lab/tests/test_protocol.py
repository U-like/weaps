import os
import sys
import time
import threading
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))
from protocol import encode, decode, STATE, STATE_FORMAT, HELLO
from rendezvous import Rendezvous
from client import P2PClient


class Tests(unittest.TestCase):
    def test_binary_hmac(self):
        key = bytes(range(32))
        payload = STATE_FORMAT.pack(123, 1.25, -2.5, 90.0)
        encoded = encode(key, STATE, 456, 1700000000000, payload)
        self.assertEqual(decode(key, encoded), (STATE, 456, 1700000000000, payload))
        mutated = bytearray(encoded)
        mutated[-17] ^= 0x08
        self.assertIsNone(decode(key, mutated))
        self.assertIsNone(decode(bytes(32), encoded))
        self.assertEqual(len(encoded), 19 + 16 + len(payload))
        print("CROSS_LANGUAGE_VECTOR", encoded.hex())

    def test_loopback_direct(self):
        rendezvous = Rendezvous("127.0.0.1", 0)
        stop = threading.Event()
        ready = threading.Event()
        server_thread = threading.Thread(target=rendezvous.serve, kwargs={"ready": ready, "stop": stop}, daemon=True)
        server_thread.start()
        self.assertTrue(ready.wait(2))
        a = P2PClient("127.0.0.1", rendezvous.port)
        b = P2PClient("127.0.0.1", rendezvous.port)
        try:
            a.host()
            deadline = time.monotonic() + 4
            while not a.stats.room and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertTrue(a.stats.room)
            b.join(a.stats.room)
            deadline = time.monotonic() + 6
            while (a.stats.status != "DIRECT" or b.stats.status != "DIRECT") and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertEqual(a.stats.status, "DIRECT")
            self.assertEqual(b.stats.status, "DIRECT")
            a.set_state(7.5, -1.0, 45.0)
            deadline = time.monotonic() + 3
            while b.stats.rx_states == 0 and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertAlmostEqual(b.stats.peer_x, 7.5)
            self.assertAlmostEqual(b.stats.peer_y, -1.0)
            self.assertEqual(a.stats.role, "host")
            self.assertEqual(b.stats.role, "guest")
            deadline = time.monotonic() + 3
            while a.stats.rtt_ms < 0 and time.monotonic() < deadline:
                time.sleep(0.05)
            self.assertGreaterEqual(a.stats.rtt_ms, 0)
            self.assertEqual(b.stats.missing_states, 0)
        finally:
            a.close()
            b.close()
            stop.set()
            server_thread.join(2)

if __name__ == '__main__':
    unittest.main(verbosity=2)
