import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'python'))
from analyze_reports import classify_pair

class AnalysisTests(unittest.TestCase):
    def test_direct(self):
        s={'status':'DIRECT','stun_mappings':{'a':'203.0.113.1:4000'},'candidate_count':1}
        self.assertEqual(classify_pair(s,s)['result'],'DIRECT_CONFIRMED')
    def test_stun_failure(self):
        self.assertEqual(classify_pair({'status':'STUN_PROBING'},{'stun_mappings':{'a':'x'}})['result'],'STUN_FAILURE')
    def test_no_punch(self):
        s={'stun_mappings':{'a':'x'},'candidate_count':1,'punch_tx':10}
        self.assertEqual(classify_pair(s, {**s,'punch_tx':0})['result'],'NO_PUNCH_SENT')
    def test_punch_failed(self):
        s={'stun_mappings':{'a':'x'},'candidate_count':1,'punch_tx':10,'punch_rx':0}
        self.assertEqual(classify_pair(s,s)['result'],'PUNCH_FAILED')

if __name__=='__main__': unittest.main()
