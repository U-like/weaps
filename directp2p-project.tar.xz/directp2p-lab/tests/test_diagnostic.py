import os
import socket
import struct
import sys
import time
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'python'))
from diagnostic import (DiagnosticPeer, COOKIE, STUN_HEADER, decode_ticket, encode_ticket,
                        parse_stun_reply, stun_request)


class DiagnosticTests(unittest.TestCase):
    def test_stun_xor_mapping_and_transaction(self):
        tx = bytes(range(12))
        mapped_ip, mapped_port = '203.0.113.45', 46899
        value = (b'\x00\x01' + struct.pack('!H', mapped_port ^ (COOKIE >> 16)) +
                 bytes(a^b for a,b in zip(socket.inet_aton(mapped_ip), struct.pack('!I', COOKIE))))
        attr = struct.pack('!HH', 0x0020, len(value)) + value
        resp = STUN_HEADER.pack(0x0101, len(attr), COOKIE, tx) + attr
        self.assertEqual(parse_stun_reply(resp, tx), (mapped_ip, mapped_port))
        self.assertIsNone(parse_stun_reply(resp, b'1'*12))
        self.assertIsNone(parse_stun_reply(resp[:-1], tx))
        self.assertEqual(len(stun_request(tx)), 20)

    def test_ticket_validation(self):
        key = bytes(range(32))
        import hashlib
        import base64
        sid = hashlib.sha256(key).hexdigest()[:16]
        offer = encode_ticket({'v':2,'kind':'offer','sid':sid,'key':base64.urlsafe_b64encode(key).decode().rstrip('='),'c':[['192.0.2.9',40000]]})
        self.assertEqual(decode_ticket(offer)['sid'],sid)
        with self.assertRaises(ValueError):
            decode_ticket(offer.replace('DPL2:', 'BAD:'))

    def test_bidirectional_direct_no_signaling_server(self):
        host = DiagnosticPeer(bind_ip='127.0.0.1', stun_servers=())
        guest = DiagnosticPeer(bind_ip='127.0.0.1', stun_servers=())
        try:
            # Same-loopback test has manually supplied public/host candidates.
            host.lan = guest.lan = '127.0.0.1'
            offer = host.create_offer()
            answer = guest.accept_offer(offer)
            host.accept_answer(answer)
            limit = time.monotonic()+5
            while time.monotonic()<limit and (host.status!='DIRECT' or guest.status!='DIRECT'):
                time.sleep(.05)
            self.assertEqual(host.status,'DIRECT',host.report())
            self.assertEqual(guest.status,'DIRECT',guest.report())
            self.assertGreater(host.punch_rx,0)
            self.assertGreater(guest.punch_rx,0)
            time.sleep(.2)
            self.assertGreater(host.states_rx,0)
            self.assertGreater(guest.states_rx,0)
        finally:
            host.close(); guest.close()

if __name__ == '__main__': unittest.main()
