package dev.directp2p.lab

import android.os.SystemClock
import android.util.Base64
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import java.util.Locale
import kotlin.concurrent.thread

/** Single UDP socket for rendezvous and peer packets: essential for NAT traversal. */
class P2PEngine(
    private val serverName: String,
    private val serverPort: Int,
    private val isHost: Boolean,
    initialRoom: String,
    private val log: (String) -> Unit
) {
    private val random = SecureRandom()
    private val clientId = ByteArray(16).also(random::nextBytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    private val wantedRoom = initialRoom.uppercase(Locale.US).trim()
    @Volatile var status = "CONNECTING"
        private set
    @Volatile var room = wantedRoom
        private set
    @Volatile var role = ""
        private set
    @Volatile var peerName = "—"
        private set
    @Volatile var localPort = 0
        private set
    @Volatile var pingMs = -1.0
        private set
    @Volatile var txStates = 0
        private set
    @Volatile var rxStates = 0
        private set
    @Volatile var missingStates = 0
        private set
    @Volatile var remoteX = 0f
        private set
    @Volatile var remoteY = 0f
        private set
    @Volatile var remoteAngle = 0f
        private set
    @Volatile var positionX = 0f
        private set
    @Volatile var positionY = 0f
        private set
    @Volatile var positionAngle = 0f
        private set
    @Volatile private var running = true
    @Volatile private var socket: DatagramSocket? = null

    private val candidates = LinkedHashSet<InetSocketAddress>()
    private var rendezvous: InetSocketAddress? = null
    private var chosenPeer: InetSocketAddress? = null
    private var key: ByteArray? = null
    private var packetSeq = random.nextInt()
    private var stateSeq = 0
    private var lastStateSeq: Int? = null
    private var lastDirectMs = 0L
    private var firstPeerMs = 0L
    private var lastRegisterMs = 0L
    private var lastPunchMs = 0L
    private var lastPingMs = 0L
    private var lastStateMs = 0L
    private var lastKeepaliveMs = 0L
    private val pendingPing = HashMap<Long, Long>()

    init {
        thread(name = "directp2p-udp", isDaemon = true) { loop() }
    }

    fun move(dx: Float, dy: Float) {
        positionX += dx
        positionY += dy
    }

    fun stop() {
        running = false
        status = "STOPPED"
        socket?.close()
    }

    fun lossPercent(): Double = missingStates.toDouble() * 100.0 / (rxStates + missingStates).coerceAtLeast(1)

    private fun setStatus(new: String, message: String) {
        status = new
        log(message)
    }

    private fun findLanIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList().asSequence() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    private fun loop() {
        try {
            val resolved = InetAddress.getByName(serverName)
            rendezvous = InetSocketAddress(resolved, serverPort)
            DatagramSocket(0).use { sock ->
                socket = sock
                sock.soTimeout = 50
                localPort = sock.localPort
                val lan = findLanIp()
                log("UDP порт: $localPort · rendezvous: ${resolved.hostAddress}:$serverPort · LAN: ${lan ?: "—"}")
                setStatus(if (isHost) "CREATING" else "JOINING", if (isHost) "Создание комнаты…" else "Вход в $wantedRoom…")
                sendRegister(sock, if (isHost) "create" else "join", lan)
                val receiveBuf = ByteArray(1500)
                while (running) {
                    val dp = DatagramPacket(receiveBuf, receiveBuf.size)
                    try {
                        sock.receive(dp)
                        val from = InetSocketAddress(dp.address, dp.port)
                        val bytes = dp.data.copyOfRange(dp.offset, dp.offset + dp.length)
                        if (bytes.isNotEmpty() && bytes[0] == '{'.code.toByte()) {
                            processControl(sock, bytes, from)
                        } else {
                            processDirect(sock, bytes, from)
                        }
                    } catch (_: java.net.SocketTimeoutException) {
                    }
                    tick(sock, lan)
                }
            }
        } catch (ex: Exception) {
            if (running) setStatus("ERROR", ex.message ?: ex.javaClass.simpleName)
        } finally {
            socket = null
        }
    }

    private fun sendJson(sock: DatagramSocket, obj: JSONObject) {
        val endpoint = rendezvous ?: return
        val bytes = obj.toString().toByteArray(Charsets.UTF_8)
        sock.send(DatagramPacket(bytes, bytes.size, endpoint))
    }

    private fun sendRegister(sock: DatagramSocket, type: String, lan: String?) {
        val msg = JSONObject().put("v", 1).put("type", type).put("client", clientId)
        if (type != "create") msg.put("room", room)
        if (lan != null) {
            msg.put("lan", JSONObject().put("ip", lan).put("port", localPort))
        }
        sendJson(sock, msg)
        lastRegisterMs = SystemClock.elapsedRealtime()
    }

    private fun endpoint(json: JSONObject?): InetSocketAddress? {
        if (json == null) return null
        return runCatching {
            val ip = InetAddress.getByName(json.getString("ip"))
            val port = json.getInt("port")
            require(port in 1..65535)
            InetSocketAddress(ip, port)
        }.getOrNull()
    }

    private fun processControl(sock: DatagramSocket, bytes: ByteArray, from: InetSocketAddress) {
        if (from != rendezvous) return
        val json = runCatching { JSONObject(String(bytes, Charsets.UTF_8)) }.getOrNull() ?: return
        if (json.optInt("v") != 1) return
        when (json.optString("type")) {
            "registered" -> {
                val registeredRoom = json.optString("room")
                if (room.isNotBlank() && registeredRoom != room) return
                val encoded = json.optString("key")
                val decoded = runCatching { Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP) }.getOrNull()
                if (decoded?.size != 32) return
                room = registeredRoom
                role = json.optString("role")
                key = decoded
                if (status == "CREATING" || status == "JOINING") {
                    setStatus("WAITING", "Комната $room создана, роль: $role. Ожидание второго игрока.")
                }
            }
            "peer" -> {
                if (json.optString("room") != room) return
                endpoint(json.optJSONObject("peer"))?.let(candidates::add)
                endpoint(json.optJSONObject("lan"))?.let(candidates::add)
                if (candidates.isNotEmpty() && firstPeerMs == 0L) {
                    firstPeerMs = SystemClock.elapsedRealtime()
                    if (status != "DIRECT") setStatus("PUNCHING", "Найдён игрок. Пробиваем NAT напрямую…")
                }
                if (key != null) sendPUNCH(sock)
            }
            "error" -> log("Rendezvous: ${json.optString("reason")}")
        }
    }

    private fun sendPUNCH(sock: DatagramSocket) {
        for (candidate in candidates) sendDirect(sock, Protocol.HELLO, byteArrayOf(), candidate)
        lastPunchMs = SystemClock.elapsedRealtime()
    }

    private fun sendDirect(sock: DatagramSocket, kind: Int, payload: ByteArray = byteArrayOf(), to: InetSocketAddress? = chosenPeer) {
        val sessionKey = key ?: return
        val endpoint = to ?: return
        packetSeq += 1
        val bytes = Protocol.encode(sessionKey, kind, packetSeq, System.currentTimeMillis(), payload)
        sock.send(DatagramPacket(bytes, bytes.size, endpoint))
        if (kind == Protocol.STATE) txStates++
    }

    private fun processDirect(sock: DatagramSocket, bytes: ByteArray, from: InetSocketAddress) {
        val sessionKey = key ?: return
        if (from != chosenPeer && from !in candidates) return
        val parsed = Protocol.decode(sessionKey, bytes) ?: return
        lastDirectMs = SystemClock.elapsedRealtime()
        if (chosenPeer != from || status != "DIRECT") {
            chosenPeer = from
            peerName = "${from.address.hostAddress}:${from.port}"
            setStatus("DIRECT", "DIRECT UDP установлен: $peerName")
        }
        when (parsed.type) {
            Protocol.HELLO -> sendDirect(sock, Protocol.HELLO_ACK, to = from)
            Protocol.PING -> if (parsed.payload.size == 8) sendDirect(sock, Protocol.PONG, parsed.payload, from)
            Protocol.PONG -> if (parsed.payload.size == 8) {
                val ticket = ByteBuffer.wrap(parsed.payload).order(ByteOrder.BIG_ENDIAN).long
                val sent = pendingPing.remove(ticket)
                if (sent != null) {
                    val measured = (SystemClock.elapsedRealtime() - sent).toDouble()
                    pingMs = if (pingMs < 0) measured else pingMs * 0.7 + measured * 0.3
                }
            }
            Protocol.STATE -> if (parsed.payload.size == 16) {
                val bb = ByteBuffer.wrap(parsed.payload).order(ByteOrder.BIG_ENDIAN)
                val nextSeq = bb.int
                val previous = lastStateSeq
                if (previous != null) {
                    val delta = (nextSeq.toLong() - previous.toLong()) and 0xffffffffL
                    if (delta == 0L || delta >= 0x80000000L) return
                    if (delta in 2..127) missingStates += (delta - 1).toInt()
                }
                lastStateSeq = nextSeq
                remoteX = bb.float
                remoteY = bb.float
                remoteAngle = bb.float
                rxStates++
            }
        }
    }

    private fun tick(sock: DatagramSocket, lan: String?) {
        val now = SystemClock.elapsedRealtime()
        if (key == null && now - lastRegisterMs > 2000) {
            sendRegister(sock, if (isHost) "create" else "join", lan)
        } else if (key != null && now - lastRegisterMs > 3000) {
            sendRegister(sock, "heartbeat", lan)
        }
        if (status != "DIRECT" && candidates.isNotEmpty() && key != null && now - lastPunchMs > 350) {
            sendPUNCH(sock)
            if (firstPeerMs > 0 && now - firstPeerMs > 15000 && status != "NAT_BLOCKED") {
                setStatus("NAT_BLOCKED", "Прямой UDP пока заблокирован NAT; продолжаю попытки.")
            }
        }
        if (status == "DIRECT") {
            if (now - lastDirectMs > 12000) {
                chosenPeer = null
                setStatus("PUNCHING", "Игрок недоступен, повторяю hole punching")
            } else {
                if (now - lastPingMs > 1000) {
                    val ticket = SystemClock.elapsedRealtimeNanos()
                    val payload = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putLong(ticket).array()
                    pendingPing[ticket] = now
                    pendingPing.entries.removeAll { now - it.value > 8000 }
                    sendDirect(sock, Protocol.PING, payload)
                    lastPingMs = now
                }
                if (now - lastKeepaliveMs > 2000) {
                    sendDirect(sock, Protocol.KEEPALIVE)
                    lastKeepaliveMs = now
                }
                if (now - lastStateMs >= 50) {
                    stateSeq++
                    sendDirect(sock, Protocol.STATE, Protocol.statePayload(stateSeq, positionX, positionY, positionAngle))
                    lastStateMs = now
                }
            }
        }
    }
}
