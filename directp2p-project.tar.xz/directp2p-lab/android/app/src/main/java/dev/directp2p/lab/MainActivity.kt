package dev.directp2p.lab

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var engine: P2PEngine? = null
    private var diag: DiagnosticEngine? = null
    private lateinit var diagInput: EditText
    private lateinit var diagStatus: TextView
    private lateinit var diagEvents: TextView
    private lateinit var addressField: EditText
    private lateinit var portField: EditText
    private lateinit var roomField: EditText
    private lateinit var status: TextView
    private lateinit var metrics: TextView
    private lateinit var logView: TextView
    private lateinit var arena: ArenaView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!Protocol.selfTest()) {
            appendLog("ОШИБКА: бинарный протокол Kotlin не совпал с эталоном Python")
        } else {
            appendLog("Протокол DPP1 проверен по Python HMAC-тесту")
        }
        ui.post(ticker)
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
            setBackgroundColor(Color.rgb(244, 247, 250))
        }
        fun label(text: String, size: Float = 15f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(24, 35, 52))
            setPadding(0, dp(6), 0, dp(5))
        }
        fun field(hint: String, value: String, width: Int = 0) = EditText(this).apply {
            setSingleLine(true)
            this.hint = hint
            setText(value)
            textSize = 16f
            if (width > 0) layoutParams = LinearLayout.LayoutParams(dp(width), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }
        page.addView(label("DirectP2P LAB 0.2 · NAT diagnostic", 25f))
        page.addView(label("Android ↔ Python / Android · прямой UDP без relay", 13f))
        page.addView(label("ДИАГНОСТИКА ИНТЕРНЕТ-P2P: STUN → OFFER/ANSWER → UDP", 17f))
        page.addView(label("Без VPS / регистрации / relay. Публичные STUN только определяют внешний IP:порт. Код OFFER передай второму устройству через мессенджер, ANSWER верни обратно. Код содержит ключ: делись только с тестовым партнёром.", 13f))
        diagStatus = label("Диагностика не запущена", 14f)
        page.addView(diagStatus)
        page.addView(button("1. Запустить STUN (подожди 4–6 сек)") { startDiag() })
        page.addView(button("2A. HOST: скопировать OFFER") { safeDiag {
            copyToClipboard("DPL2 OFFER", it.createOffer())
            appendLog("OFFER скопирован. Отправь его другому игроку. Не публикуй в общий чат.")
        } })
        page.addView(label("Поле для OFFER (на JOIN) или ANSWER (на HOST):", 13f))
        diagInput = EditText(this).apply {
            hint = "Вставь сюда DPL2:..."
            minLines = 2; maxLines = 4
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextIsSelectable(true)
        }
        page.addView(diagInput)
        page.addView(button("2B. JOIN: применить OFFER и скопировать ANSWER") { safeDiag {
            val ticket = it.joinOffer(diagInput.text.toString())
            copyToClipboard("DPL2 ANSWER", ticket)
            appendLog("ANSWER скопирован. Отправь его HOST, затем вернись в диагностику.")
        } })
        page.addView(button("3. HOST: применить ANSWER — начать PUNCHING") { safeDiag {
            it.acceptAnswer(diagInput.text.toString())
            appendLog("ANSWER принят. Обе стороны пробивают NAT. Жди 25 секунд.")
        } })
        page.addView(button("Скопировать диагностический отчёт (JSON)") { safeDiag {
            copyToClipboard("DirectP2P report", it.report())
            appendLog("Отчёт скопирован. В нём нет секретного ключа OFFER.")
        } })
        page.addView(button("Остановить диагностику") { diag?.stop(); diag = null })
        diagEvents = label("STUN не запускался", 12f)
        diagEvents.setTextIsSelectable(true)
        page.addView(diagEvents)

        page.addView(label("СТАРЫЙ РЕЖИМ: комнаты через свой rendezvous", 17f))
        page.addView(label("Rendezvous: публичный IPv4/домен или адрес ПК в одной Wi-Fi сети"))
        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addressField = field("IP или домен", "", 0)
        addressField.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        portField = field("UDP порт", "34781", 108)
        portField.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        addressRow.addView(addressField)
        addressRow.addView(portField)
        page.addView(addressRow)

        page.addView(label("Код комнаты — вводится только при подключении"))
        roomField = field("Например: ABCD234567", "")
        page.addView(roomField)
        val connectionButtons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        connectionButtons.addView(button("Создать комнату · HOST") { start(true) })
        connectionButtons.addView(button("Войти в комнату · JOIN") { start(false) })
        connectionButtons.addView(button("Остановить тест") { stop() })
        page.addView(connectionButtons)

        status = label("IDLE", 22f)
        page.addView(status)
        metrics = label("Пока нет соединения", 14f)
        page.addView(metrics)
        page.addView(label("Тестовая игровая сцена (синий — ты, красный — другой игрок)", 13f))
        arena = ArenaView()
        page.addView(arena, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(200)))
        page.addView(label("Стрелки перемещают позицию; координаты отправляются ~20 раз/сек.", 13f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        controls.addView(button("↑") { move(0f, 1f) })
        val middle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        middle.addView(button("←") { move(-1f, 0f) })
        middle.addView(button("↓") { move(0f, -1f) })
        middle.addView(button("→") { move(1f, 0f) })
        controls.addView(middle)
        page.addView(controls)
        page.addView(label("Журнал:", 14f))
        logView = label("", 12f)
        logView.setTextIsSelectable(true)
        page.addView(logView)
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun startDiag() {
        diag?.stop()
        diag = DiagnosticEngine { event -> ui.post { appendLog("DIAG $event") } }
        appendLog("Диагностика запущена. Подожди STUN_MAPPED, потом копируй OFFER.")
    }

    private inline fun safeDiag(action: (DiagnosticEngine) -> Unit) {
        val instance = diag
        if (instance == null) { appendLog("Сначала нажми Запустить STUN"); return }
        try { action(instance) } catch (e: Exception) {
            appendLog("DIAG ERROR: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun copyToClipboard(label: String, value: String) {
        val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        manager.setPrimaryClip(ClipData.newPlainText(label, value))
    }

    private fun start(host: Boolean) {
        val address = addressField.text.toString().trim()
        val port = portField.text.toString().toIntOrNull()
        val room = roomField.text.toString().trim()
        if (address.isEmpty() || port == null || port !in 1..65535) {
            appendLog("Укажи адрес и UDP порт rendezvous-сервера")
            return
        }
        if (!host && room.isEmpty()) {
            appendLog("Для JOIN введи код комнаты хоста")
            return
        }
        stop()
        engine = P2PEngine(address, port, host, room) { message ->
            ui.post { appendLog(message) }
        }
        appendLog("Старт ${if (host) "HOST" else "JOIN"} через $address:$port")
    }

    private fun stop() {
        engine?.stop()
        engine = null
    }

    private fun move(dx: Float, dy: Float) {
        engine?.move(dx, dy) ?: appendLog("Сначала создай комнату или подключись")
    }

    private val ticker = object : Runnable {
        override fun run() {
            val d = diag
            if (d != null) {
                val ping = if (d.rttMs < 0) "—" else String.format(Locale.US, "%.1f ms", d.rttMs)
                diagStatus.text = "${d.status} | ${d.role} | UDP:${d.localPort} | RTT $ping"
                diagEvents.text = "${d.stunSummary}\nPeer: ${d.peerName}\nPUNCH: ${d.punchTx}/${d.punchRx}\nTX/RX: ${d.txPackets}/${d.rxPackets}  STATE: ${d.gameTx}/${d.gameRx}"
            } else {
                diagStatus.text = "Диагностика остановлена"
            }
            val e = engine
            if (e != null) {
                status.text = "${e.status}  ${e.role}  ${e.room}"
                val ping = if (e.pingMs < 0) "—" else String.format(Locale.US, "%.1f мс", e.pingMs)
                metrics.text = "Peer: ${e.peerName}\nRTT: $ping   UDP local port: ${e.localPort}" +
                    "\nTX: ${e.txStates}  RX: ${e.rxStates}  Loss≈${String.format(Locale.US, "%.1f", e.lossPercent())}%" +
                    "\nТы: (${e.positionX.toInt()}, ${e.positionY.toInt()})  Партнёр: (${e.remoteX.toInt()}, ${e.remoteY.toInt()})"
                arena.update(e.positionX, e.positionY, e.remoteX, e.remoteY)
                if (e.room.isNotEmpty() && roomField.text.toString() != e.room && e.role == "host") {
                    roomField.setText(e.room)
                }
            } else {
                status.text = "IDLE"
            }
            ui.postDelayed(this, 200)
        }
    }

    private fun appendLog(message: String) {
        if (!::logView.isInitialized) return
        val old = logView.text.toString().lines().takeLast(15).joinToString("\n").trim()
        logView.text = if (old.isBlank()) message else "$old\n$message"
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        stop()
        diag?.stop()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private inner class ArenaView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lx = 0f
        private var ly = 0f
        private var rx = 0f
        private var ry = 0f

        fun update(x: Float, y: Float, peerX: Float, peerY: Float) {
            lx = x; ly = y; rx = peerX; ry = peerY
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(224, 235, 247))
            paint.strokeWidth = dp(1).toFloat()
            paint.color = Color.rgb(185, 204, 224)
            for (i in -4..4) {
                val posX = width / 2f + i * dp(25)
                val posY = height / 2f + i * dp(25)
                canvas.drawLine(posX, 0f, posX, height.toFloat(), paint)
                canvas.drawLine(0f, posY, width.toFloat(), posY, paint)
            }
            val scale = dp(6).toFloat()
            paint.color = Color.rgb(28, 105, 221)
            canvas.drawCircle(width / 2f + lx * scale, height / 2f - ly * scale, dp(9).toFloat(), paint)
            paint.color = Color.rgb(218, 66, 75)
            canvas.drawCircle(width / 2f + rx * scale, height / 2f - ry * scale, dp(9).toFloat(), paint)
        }
    }
}
