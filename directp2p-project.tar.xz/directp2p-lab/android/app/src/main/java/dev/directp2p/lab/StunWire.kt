package dev.directp2p.lab

import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** RFC 5389 STUN Binding transactions on the *same UDP socket* as DPP1 packets. */
object StunWire {
    private const val COOKIE = 0x2112A442
    fun request(txid: ByteArray): ByteArray {
        require(txid.size == 12)
        return ByteBuffer.allocate(20).order(ByteOrder.BIG_ENDIAN)
            .putShort(0x0001.toShort()).putShort(0).putInt(COOKIE).put(txid).array()
    }
    data class Mapping(val ip: String, val port: Int)
    fun parseReply(bytes: ByteArray, expectedTxid: ByteArray): Mapping? {
        if (bytes.size < 20 || expectedTxid.size != 12) return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        val type = bb.short.toInt() and 65535
        val length = bb.short.toInt() and 65535
        val cookie = bb.int
        val txid = ByteArray(12).also(bb::get)
        if (type != 0x0101 || cookie != COOKIE || !txid.contentEquals(expectedTxid) || length % 4 != 0 || length + 20 > bytes.size) return null
        var offset = 20
        while (offset + 4 <= length + 20) {
            bb.position(offset)
            val kind = bb.short.toInt() and 65535
            val size = bb.short.toInt() and 65535
            val start = offset + 4
            if (start + size > length + 20) return null
            if ((kind == 0x0020 || kind == 0x0001) && size >= 8 && bytes[start + 1].toInt() == 1) {
                var port = ByteBuffer.wrap(bytes, start + 2, 2).order(ByteOrder.BIG_ENDIAN).short.toInt() and 65535
                val addr = bytes.copyOfRange(start + 4, start + 8)
                if (kind == 0x0020) {
                    port = port xor (COOKIE ushr 16)
                    val cookieBytes = ByteBuffer.allocate(4).putInt(COOKIE).array()
                    for (i in 0..3) addr[i] = (addr[i].toInt() xor cookieBytes[i].toInt()).toByte()
                }
                return if (port > 0) Mapping(InetAddress.getByAddress(addr).hostAddress.orEmpty(), port) else null
            }
            offset = start + ((size + 3) and -4)
        }
        return null
    }
    fun hasCookie(bytes: ByteArray): Boolean = bytes.size >= 20 &&
        ByteBuffer.wrap(bytes, 4, 4).order(ByteOrder.BIG_ENDIAN).int == COOKIE
    fun transaction(bytes: ByteArray): ByteArray = bytes.copyOfRange(8, 20)
}
