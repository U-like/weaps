package dev.directp2p.lab

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Wire format identical to python/protocol.py. Integrity-authenticated, NOT encrypted. */
object Protocol {
    const val HELLO = 1
    const val HELLO_ACK = 2
    const val PING = 3
    const val PONG = 4
    const val STATE = 5
    const val KEEPALIVE = 6
    private val magic = byteArrayOf(0x44, 0x50, 0x50, 0x31) // DPP1
    private const val HEADER_SIZE = 19
    private const val TAG_SIZE = 16
    const val MAX_PAYLOAD = 1000

    data class Packet(val type: Int, val sequence: Int, val timestampMs: Long, val payload: ByteArray)

    private fun mac(key: ByteArray, bytes: ByteArray): ByteArray {
        val hmac = Mac.getInstance("HmacSHA256")
        hmac.init(SecretKeySpec(key, "HmacSHA256"))
        return hmac.doFinal(bytes).copyOf(TAG_SIZE)
    }

    fun encode(key: ByteArray, type: Int, sequence: Int, timestampMs: Long, payload: ByteArray = byteArrayOf()): ByteArray {
        require(key.size >= 16 && type in 0..255 && payload.size <= MAX_PAYLOAD)
        val body = ByteBuffer.allocate(HEADER_SIZE + payload.size).order(ByteOrder.BIG_ENDIAN)
            .put(magic)
            .put(type.toByte())
            .putInt(sequence)
            .putLong(timestampMs)
            .putShort(payload.size.toShort())
            .put(payload)
            .array()
        return body + mac(key, body)
    }

    fun decode(key: ByteArray, datagram: ByteArray): Packet? {
        if (key.size < 16 || datagram.size !in (HEADER_SIZE + TAG_SIZE)..(HEADER_SIZE + MAX_PAYLOAD + TAG_SIZE)) return null
        if (!datagram.copyOfRange(0, 4).contentEquals(magic)) return null
        val header = ByteBuffer.wrap(datagram).order(ByteOrder.BIG_ENDIAN)
        header.position(4)
        val type = header.get().toInt() and 255
        val sequence = header.int
        val timestamp = header.long
        val length = header.short.toInt() and 65535
        if (length > MAX_PAYLOAD || datagram.size != HEADER_SIZE + length + TAG_SIZE) return null
        val body = datagram.copyOfRange(0, HEADER_SIZE + length)
        if (!MessageDigest.isEqual(mac(key, body), datagram.copyOfRange(body.size, datagram.size))) return null
        return Packet(type, sequence, timestamp, datagram.copyOfRange(HEADER_SIZE, body.size))
    }

    fun statePayload(sequence: Int, x: Float, y: Float, angle: Float): ByteArray =
        ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN)
            .putInt(sequence).putFloat(x).putFloat(y).putFloat(angle).array()

    /** Fixed vector from Python unit test: catches encoding/endian/HMAC regressions. */
    fun selfTest(): Boolean {
        val key = ByteArray(32) { it.toByte() }
        val payload = statePayload(123, 1.25f, -2.5f, 90f)
        val hex = encode(key, STATE, 456, 1_700_000_000_000L, payload)
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        return hex == "4450503105000001c80000018bcfe5680000100000007b3fa00000c020000042b4000026f5716529be4bdf9bff0978cb796310"
    }
}
