package dev.directp2p.lab

import android.os.SystemClock
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import kotlin.concurrent.thread

/** STUN + manual OFFER/ANSWER + direct authenticated DPP1; never sends game data via a server. */
class DiagnosticEngine(private val log: (String) -> Unit) {
    private val lock = Any()
    private val random = SecureRandom()
    @Volatile var status = "STARTING"; private set
    @Volatile var localPort = 0; private set
    @Volatile var rttMs = -1.0; private set
    @Volatile var peerName = "—"; private set
    @Volatile var txPackets = 0; private set
    @Volatile var rxPackets = 0; private set
    @Volatile var punchTx = 0; private set
    @Volatile var punchRx = 0; private set
    @Volatile var gameTx = 0; private set
    @Volatile var gameRx = 0; private set
    @Volatile var role = "none"; private set
    @Volatile var stunSummary = "STUN: ожидаем"; private set
    private val begun = SystemClock.elapsedRealtime()
    private val events = ArrayList<JSONObject>()
    private var key: ByteArray? = null
    private var sid = ""
    private var lanIp: String? = null
    private var socket: DatagramSocket? = null
    private val targets = ArrayList<Pair<InetSocketAddress, String>>()
    private val mappings = LinkedHashMap<String, InetSocketAddress>()
    private val outstanding = HashMap<String, Triple<String, Long, InetSocketAddress>>()
    private val candidates = LinkedHashSet<InetSocketAddress>()
    private var selected: InetSocketAddress? = null
    private var peerStart = 0L
    private var lastPacket = 0L
    private var lastStun = 0L
    private var lastPunch = 0L
    private var lastPing = 0L
    private var lastGame = 0L
    private var sequence = random.nextInt()
    private var gameSequence = 0
    private val pending = HashMap<Long, Long>()
    @Volatile private var running = true
    private val worker = thread(name = "directp2p-diag", isDaemon = true) { loop() }

    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun unb64(text: String): ByteArray = Base64.decode(text, Base64.URL_SAFE or Base64.NO_WRAP)
    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(Locale.US, it.toInt() and 255) }
    private fun event(name: String, detail: String = "") {
        synchronized(lock) {
            if (events.size >= 1200) events.removeAt(0)
            events.add(JSONObject().put("ms", SystemClock.elapsedRealtime() - begun).put("event", name).put("detail", detail))
        }
        log("$name: $detail")
    }
    private fun getLanIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList().asSequence() }
            .filterIsInstance<Inet4Address>().firstOrNull { !it.isLoopbackAddress }?.hostAddress
    }.getOrNull()

    private fun endpoint(ip: String, port: Int): InetSocketAddress {
        require(port in 1..65535)
        val addr = InetAddress.getByName(ip)
        require(addr is Inet4Address && addr.hostAddress == ip) { "Только цифровые IPv4 адреса" }
        return InetSocketAddress(addr, port)
    }

    private fun candidatesJson(): JSONArray {
        val all = LinkedHashSet<InetSocketAddress>()
        all.addAll(mappings.values)
        lanIp?.let { all.add(endpoint(it, localPort)) }
        return JSONArray().apply { all.take(24).forEach { put(JSONArray().put(it.address.hostAddress).put(it.port)) } }
    }
    private fun encodeTicket(obj: JSONObject): String = "DPL2:" + b64(obj.toString().toByteArray(Charsets.UTF_8))
    private fun decodeTicket(input: String, kind: String): JSONObject {
        val ticket = input.filterNot(Char::isWhitespace)
        require(ticket.startsWith("DPL2:") && ticket.length <= 8000) { "Нужен DPL2:$kind код" }
        val obj = JSONObject(String(unb64(ticket.substring(5)), Charsets.UTF_8))
        require(obj.optInt("v") == 2 && obj.optString("kind") == kind && obj.optString("sid").length == 16)
        val list = obj.getJSONArray("c")
        require(list.length() <= 24)
        repeat(list.length()) { i ->
            val item = list.getJSONArray(i)
            require(item.length() == 2)
            endpoint(item.getString(0), item.getInt(1))
        }
        return obj
    }
    private fun readCandidates(obj: JSONObject): Set<InetSocketAddress> {
        val result = LinkedHashSet<InetSocketAddress>()
        val list = obj.getJSONArray("c")
        repeat(list.length()) { i ->
            val item = list.getJSONArray(i)
            result.add(endpoint(item.getString(0), item.getInt(1)))
        }
        return result
    }

    /** Offer is a PRIVATE ticket: contains a random key; do not post it publicly. */
    fun createOffer(): String = synchronized(lock) {
        check(localPort > 0) { "UDP еще не запущен" }
        check(role == "none" || role == "host") { "Уже выбран JOIN" }
        if (key == null) {
            key = ByteArray(32).also(random::nextBytes)
            sid = hex(MessageDigest.getInstance("SHA-256").digest(key)).take(16)
        }
        role = "host"
        event("offer_ready", "STUN адресов=${mappings.size}")
        encodeTicket(JSONObject().put("v", 2).put("kind", "offer").put("sid", sid)
            .put("key", b64(key!!)).put("c", candidatesJson()))
    }
    fun joinOffer(ticket: String): String = synchronized(lock) {
        check(localPort > 0) { "UDP еще не запущен" }
        check(role != "host") { "Этот сокет уже HOST" }
        val o = decodeTicket(ticket, "offer")
        val decodedKey = unb64(o.getString("key"))
        require(decodedKey.size == 32 && hex(MessageDigest.getInstance("SHA-256").digest(decodedKey)).take(16) == o.getString("sid")) { "Ключ OFFER не совпадает" }
        key = decodedKey; sid = o.getString("sid"); role = "join"
        candidates.clear(); candidates.addAll(readCandidates(o))
        peerStart = SystemClock.elapsedRealtime(); status = "PUNCHING"
        event("offer_applied", "peer адресов=${candidates.size}")
        encodeTicket(JSONObject().put("v", 2).put("kind", "answer").put("sid", sid).put("c", candidatesJson()))
    }
    fun acceptAnswer(ticket: String) = synchronized(lock) {
        check(role == "host") { "Сначала создать OFFER" }
        val obj = decodeTicket(ticket, "answer")
        require(obj.getString("sid") == sid && !obj.has("key")) { "ANSWER от другой сессии" }
        candidates.clear(); candidates.addAll(readCandidates(obj))
        peerStart = SystemClock.elapsedRealtime(); status = "PUNCHING"
        event("answer_applied", "peer адресов=${candidates.size}")
    }

    private fun send(sock: DatagramSocket, data: ByteArray, to: InetSocketAddress) {
        sock.send(DatagramPacket(data, data.size, to))
    }
    private fun sendGame(sock: DatagramSocket, kind: Int, payload: ByteArray = byteArrayOf(), to: InetSocketAddress? = selected) {
        val secret = synchronized(lock) { key?.clone() } ?: return
        if (to == null) return
        sequence++
        try {
            send(sock, Protocol.encode(secret, kind, sequence, System.currentTimeMillis(), payload), to)
            txPackets++
            if (kind == Protocol.STATE) gameTx++
        } catch (e: Exception) { event("udp_send_error", e.message ?: "unknown") }
    }
    private fun stun(sock: DatagramSocket) {
        targets.forEach { (to, host) ->
            val txid = ByteArray(12).also(random::nextBytes)
            synchronized(lock) { outstanding[hex(txid)] = Triple(host, SystemClock.elapsedRealtime(), to) }
            try { send(sock, StunWire.request(txid), to) }
            catch (e: Exception) { event("stun_send_error", "$host ${e.message}") }
        }
        lastStun = SystemClock.elapsedRealtime()
    }
    private fun readStun(bytes: ByteArray, from: InetSocketAddress): Boolean {
        if (!StunWire.hasCookie(bytes)) return false
        val tx = hex(StunWire.transaction(bytes))
        val attempt = synchronized(lock) { outstanding.remove(tx) } ?: return true
        if (from != attempt.third) { event("stun_unexpected_source", attempt.first); return true }
        val mapped = StunWire.parseReply(bytes, StunWire.transaction(bytes))
        if (mapped == null) { event("stun_invalid", attempt.first); return true }
        val newAddress = endpoint(mapped.ip, mapped.port)
        synchronized(lock) {
            if (mappings[attempt.first] != newAddress) {
                mappings[attempt.first] = newAddress
                val all = mappings.values.map { "${it.address.hostAddress}:${it.port}" }.distinct()
                stunSummary = mappings.map { "${it.key}: ${it.value.address.hostAddress}:${it.value.port}" }.joinToString("\n")
                event("stun_mapped", "${attempt.first}=${mapped.ip}:${mapped.port} RTT=${SystemClock.elapsedRealtime()-attempt.second}ms mapping_varies=${all.size>1}")
            }
            if (role == "none") status = "STUN_OK"
        }
        return true
    }
    private fun readGame(sock: DatagramSocket, bytes: ByteArray, from: InetSocketAddress) {
        val secret = synchronized(lock) { if (peerStart > 0) key?.clone() else null } ?: return
        val packet = Protocol.decode(secret, bytes) ?: return
        rxPackets++
        lastPacket = SystemClock.elapsedRealtime()
        synchronized(lock) {
            if (selected != from || status != "DIRECT") {
                selected = from
                peerName = "${from.address.hostAddress}:${from.port}"
                status = "DIRECT"
                event("direct_established", "$peerName matched=${from in candidates}")
            }
        }
        when (packet.type) {
            Protocol.HELLO -> { punchRx++; sendGame(sock, Protocol.HELLO_ACK, to=from) }
            Protocol.HELLO_ACK -> punchRx++
            Protocol.PING -> if (packet.payload.size == 8) sendGame(sock, Protocol.PONG, packet.payload, from)
            Protocol.PONG -> if (packet.payload.size == 8) {
                val token = ByteBuffer.wrap(packet.payload).order(ByteOrder.BIG_ENDIAN).long
                val sent = pending.remove(token)
                if (sent != null) {
                    val next = (SystemClock.elapsedRealtime()-sent).toDouble()
                    rttMs = if (rttMs < 0) next else rttMs*.8 + next*.2
                }
            }
            Protocol.STATE -> if (packet.payload.size == 16) gameRx++
        }
    }
    private fun loop() {
        try {
            val ip = getLanIp(); lanIp = ip
            // Resolve hosts independently: a DNS failure is logged, not fatal.
            listOf("stun.l.google.com" to 19302, "stun.cloudflare.com" to 3478).forEach { (host, port) ->
                try {
                    val addr = InetAddress.getAllByName(host).filterIsInstance<Inet4Address>().firstOrNull()
                    if (addr != null) { targets.add(InetSocketAddress(addr, port) to host); event("dns_ok", "$host=${addr.hostAddress}") }
                    else event("dns_fail", "$host no A record")
                } catch (e: Exception) { event("dns_fail", "$host ${e.javaClass.simpleName}") }
            }
            DatagramSocket(0).use { sock ->
                socket = sock; sock.soTimeout=80; localPort=sock.localPort
                status = "STUN_PROBING"
                event("socket_open", "port=$localPort IPv4 lan=${lanIp ?: "unknown"}")
                val receive = ByteArray(1600)
                while (running) {
                    try {
                        val dp = DatagramPacket(receive, receive.size)
                        sock.receive(dp)
                        val bytes = dp.data.copyOfRange(dp.offset, dp.offset+dp.length)
                        val from = InetSocketAddress(dp.address, dp.port)
                        if (!readStun(bytes, from)) readGame(sock, bytes, from)
                    } catch (_: SocketTimeoutException) {} catch (e: Exception) { if (running) event("recv_error", e.message ?: "unknown") }
                    val now = SystemClock.elapsedRealtime()
                    if (now-lastStun > if (mappings.isEmpty()) 3000 else 6000) stun(sock)
                    synchronized(lock) {
                        val it = outstanding.iterator()
                        while (it.hasNext()) {
                            val entry = it.next()
                            if (now-entry.value.second > 2500) {
                                if (!mappings.containsKey(entry.value.first)) event("stun_timeout", entry.value.first)
                                it.remove()
                            }
                        }
                        if (peerStart > 0 && candidates.isNotEmpty() && status != "DIRECT" && now-lastPunch > 350) {
                            candidates.forEach { sendGame(sock, Protocol.HELLO, to=it); punchTx++ }
                            lastPunch=now
                            if (now-peerStart > 25000 && status != "DIRECT_FAILED") {
                                status = "DIRECT_FAILED"; event("direct_timeout", "25s peer addresses=${candidates.size}")
                            }
                        }
                    }
                    if (status == "DIRECT") {
                        if (now-lastPacket > 10000) {
                            synchronized(lock) { status = "PUNCHING"; selected = null }
                            event("direct_lost", "10 seconds without peer traffic")
                        } else {
                            if (now-lastPing > 1000) {
                                val token=random.nextLong(); pending[token]=now
                                sendGame(sock, Protocol.PING, ByteBuffer.allocate(8).putLong(token).array())
                                lastPing=now
                            }
                            if (now-lastGame > 50) {
                                gameSequence++
                                sendGame(sock, Protocol.STATE, Protocol.statePayload(gameSequence, gameSequence.toFloat(), 0f, 0f))
                                lastGame=now
                            }
                        }
                    }
                    val pi=pending.iterator()
                    while(pi.hasNext()) if(now-pi.next().value>5000) pi.remove()
                }
            }
        } catch (e: Exception) {
            if (running) { status = "ERROR"; event("error", e.message ?: e.javaClass.simpleName) }
        } finally { socket=null }
    }
    fun report(): String = synchronized(lock) {
        val map = JSONObject()
        mappings.forEach { (name, addr) -> map.put(name, "${addr.address.hostAddress}:${addr.port}") }
        val paths=JSONArray(); candidates.forEach { paths.put("${it.address.hostAddress}:${it.port}") }
        val ev=JSONArray(); events.forEach(ev::put)
        val result = JSONObject().put("version", 2).put("platform", "android")
            .put("role", role).put("session", sid).put("status", status)
            .put("duration_s", (SystemClock.elapsedRealtime()-begun)/1000.0)
            .put("lan_ipv4", lanIp).put("local_udp_port", localPort)
            .put("stun_mappings", map).put("mapping_varies_by_destination", mappings.values.toSet().size > 1)
            .put("peer_candidates", paths).put("selected_peer", peerName)
            .put("punch_tx", punchTx).put("punch_rx", punchRx)
            .put("total_tx", txPackets).put("total_rx", rxPackets)
            .put("game_tx", gameTx).put("game_rx", gameRx).put("rtt_ms", rttMs).put("events", ev)
        result.toString(2)
    }
    fun stop() { running = false; status = "STOPPED"; socket?.close() }
}
